/* Self-tests for the core: CPU semantics and cycle counts on a flat bus, iNES
 * loading, mapper behaviour, and an end-to-end boot of a synthetic NROM ROM. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "cart.h"
#include "cpu.h"
#include "nes.h"
#include "ppu.h"

static int failures = 0;
static int checks = 0;

#define CHECK(cond, ...)                                              \
    do {                                                              \
        checks++;                                                     \
        if (!(cond)) {                                                \
            failures++;                                               \
            fprintf(stderr, "FAIL %s:%d: ", __FILE__, __LINE__);      \
            fprintf(stderr, __VA_ARGS__);                             \
            fputc('\n', stderr);                                      \
        }                                                             \
    } while (0)

/* ---- flat 64 KiB bus for CPU tests ------------------------------------- */

typedef struct Flat {
    uint8_t mem[0x10000];
} Flat;

static uint8_t flat_read(void *ctx, uint16_t a) {
    return ((Flat *)ctx)->mem[a];
}

static void flat_write(void *ctx, uint16_t a, uint8_t v) {
    ((Flat *)ctx)->mem[a] = v;
}

static void flat_setup(CPU *c, Flat *f, uint16_t org, const uint8_t *code, size_t n) {
    memset(f, 0, sizeof *f);
    memcpy(&f->mem[org], code, n);
    f->mem[0xFFFC] = (uint8_t)org;
    f->mem[0xFFFD] = (uint8_t)(org >> 8);
    cpu_init(c, (CpuBus){flat_read, flat_write, f});
    c->pc = org;
    c->s = 0xFD;
    c->p = CPU_FLAG_U;
}

static void run_until_pc(CPU *c, uint16_t stop, int max_steps) {
    for (int i = 0; i < max_steps && c->pc != stop; i++) {
        cpu_step(c);
    }
}

/* ---- CPU semantics ------------------------------------------------------- */

static void test_program_subroutine_loop(void) {
    static const uint8_t code[] = {
        0xA9, 0x10,             /* 8000 LDA #$10          */
        0x69, 0x20,             /* 8002 ADC #$20          */
        0x85, 0x00,             /* 8004 STA $00           */
        0x20, 0x20, 0x80,       /* 8006 JSR $8020         */
        0xA2, 0x05,             /* 8009 LDX #5            */
        0xCA,                   /* 800B DEX               */
        0xD0, 0xFD,             /* 800C BNE $800B         */
        0x4C, 0x0E, 0x80,       /* 800E JMP $800E         */
    };
    static const uint8_t sub[] = {0xA9, 0x77, 0x60}; /* LDA #$77; RTS at $8020 */
    CPU c;
    Flat f;
    flat_setup(&c, &f, 0x8000, code, sizeof code);
    memcpy(&f.mem[0x8020], sub, sizeof sub);
    run_until_pc(&c, 0x800E, 200);
    CHECK(c.pc == 0x800E, "loop program did not reach $800E (pc=$%04X)", c.pc);
    CHECK(c.a == 0x77, "A expected $77, got $%02X", c.a);
    CHECK(c.x == 0, "X expected 0, got $%02X", c.x);
    CHECK(f.mem[0x00] == 0x30, "mem[0] expected $30, got $%02X", f.mem[0]);
    CHECK(c.s == 0xFD, "stack not balanced after JSR/RTS (S=$%02X)", c.s);
    CHECK((c.p & CPU_FLAG_C) == 0, "carry should be clear");
}

static void test_flags_and_bcd_free_adc_sbc(void) {
    static const uint8_t code[] = {
        0xA9, 0x50,             /* LDA #$50        */
        0x69, 0x50,             /* ADC #$50 -> $A0, V=1 N=1 C=0 */
        0x08,                   /* PHP             */
        0x68,                   /* PLA             */
        0x85, 0x10,             /* STA $10         */
        0xA9, 0x00,             /* LDA #$00        */
        0x38,                   /* SEC             */
        0xE9, 0x01,             /* SBC #$01 -> $FF, C=0 */
        0x85, 0x11,             /* STA $11         */
        0x4C, 0x0F, 0x80,       /* 800F JMP self  */
    };
    CPU c;
    Flat f;
    flat_setup(&c, &f, 0x8000, code, sizeof code);
    run_until_pc(&c, 0x800F, 100);
    CHECK(f.mem[0x10] == 0xF0, "PHP flags expected $F0 (N V B U), got $%02X", f.mem[0x10]);
    CHECK(f.mem[0x11] == 0xFF, "SBC result expected $FF, got $%02X", f.mem[0x11]);
    CHECK((c.p & CPU_FLAG_C) == 0, "SBC borrow should clear carry");
    CHECK((c.p & CPU_FLAG_N) != 0, "N should be set after SBC $FF");
}

static void test_indexed_and_shifts(void) {
    static const uint8_t code[] = {
        0xA2, 0x01,             /* LDX #1          */
        0xBD, 0x00, 0x02,       /* LDA $0200,X     */
        0x9D, 0x10, 0x02,       /* STA $0210,X     */
        0xA9, 0x81,             /* LDA #$81        */
        0x0A,                   /* ASL A -> $02, C=1 */
        0x6A,                   /* ROR A -> $81, C=0 */
        0x4C, 0x0C, 0x80,       /* 800C JMP self  */
    };
    CPU c;
    Flat f;
    flat_setup(&c, &f, 0x8000, code, sizeof code);
    f.mem[0x0201] = 0x5A;
    run_until_pc(&c, 0x800C, 100);
    CHECK(f.mem[0x0211] == 0x5A, "indexed store expected $5A, got $%02X", f.mem[0x0211]);
    CHECK(c.a == 0x81, "ASL/ROR result expected $81, got $%02X", c.a);
    CHECK((c.p & CPU_FLAG_C) == 0, "ROR should leave carry clear");
}

static void test_undocumented_lax_sax(void) {
    static const uint8_t code[] = {
        0xA7, 0x20,             /* LAX $20  -> A=X=mem[$20] */
        0x87, 0x21,             /* SAX $21  -> mem[$21]=A&X */
        0x4C, 0x04, 0x80,       /* JMP self */
    };
    CPU c;
    Flat f;
    flat_setup(&c, &f, 0x8000, code, sizeof code);
    f.mem[0x20] = 0xC3;
    run_until_pc(&c, 0x8004, 50);
    CHECK(c.a == 0xC3 && c.x == 0xC3, "LAX: A=$%02X X=$%02X", c.a, c.x);
    CHECK(f.mem[0x21] == 0xC3, "SAX expected $C3, got $%02X", f.mem[0x21]);
}

/* Measures the cycles one instruction takes, from a given opcode sequence. */
static uint64_t cycles_of(const uint8_t *code, size_t n, uint16_t org, void (*setup)(CPU *, Flat *)) {
    CPU c;
    Flat f;
    flat_setup(&c, &f, org, code, n);
    if (setup) {
        setup(&c, &f);
    }
    uint64_t before = c.cycles;
    cpu_step(&c);
    return c.cycles - before;
}

static void setup_x1(CPU *c, Flat *f) {
    (void)f;
    c->x = 1;
}

static void setup_z_clear(CPU *c, Flat *f) {
    (void)f;
    c->p &= ~CPU_FLAG_Z;
}

static void setup_z_set(CPU *c, Flat *f) {
    (void)f;
    c->p |= CPU_FLAG_Z;
}

static void setup_ind_at_10(CPU *c, Flat *f) {
    (void)c;
    f->mem[0x10] = 0x00;
    f->mem[0x11] = 0x02;
    c->y = 1;
}

static void setup_stack_rti(CPU *c, Flat *f) {
    c->s = 0xFA;
    f->mem[0x01FB] = 0x00; /* P */
    f->mem[0x01FC] = 0x00; /* PCL */
    f->mem[0x01FD] = 0x90; /* PCH */
}

static void setup_stack_rts(CPU *c, Flat *f) {
    c->s = 0xFB;
    f->mem[0x01FC] = 0x33;
    f->mem[0x01FD] = 0x80;
}

static void setup_pha(CPU *c, Flat *f) {
    (void)f;
    c->a = 0x42;
}

static void setup_jmpind(CPU *c, Flat *f) {
    (void)c;
    f->mem[0x0200] = 0x00;
    f->mem[0x0201] = 0x90;
}

static void test_cycle_counts(void) {
    struct Case {
        const char *name;
        uint8_t code[3];
        size_t len;
        uint16_t org;
        int expect;
        void (*setup)(CPU *, Flat *);
    } cases[] = {
        {"NOP", {0xEA}, 1, 0x8000, 2, NULL},
        {"LDA #", {0xA9, 0x01}, 2, 0x8000, 2, NULL},
        {"LDA zp", {0xA5, 0x10}, 2, 0x8000, 3, NULL},
        {"LDA abs", {0xAD, 0x00, 0x02}, 3, 0x8000, 4, NULL},
        {"LDA abs,X no cross", {0xBD, 0x00, 0x02}, 3, 0x8000, 4, setup_x1},
        {"LDA abs,X cross", {0xBD, 0xFF, 0x02}, 3, 0x8000, 5, setup_x1},
        {"STA abs,X", {0x9D, 0x00, 0x02}, 3, 0x8000, 5, setup_x1},
        {"LDA (zp),Y no cross", {0xB1, 0x10}, 2, 0x8000, 5, setup_ind_at_10},
        {"LDA (zp,X)", {0xA1, 0x10}, 2, 0x8000, 6, NULL},
        {"INC zp", {0xE6, 0x10}, 2, 0x8000, 5, NULL},
        {"ASL abs", {0x0E, 0x00, 0x02}, 3, 0x8000, 6, NULL},
        {"ASL A", {0x0A}, 1, 0x8000, 2, NULL},
        {"DEC abs,X", {0xDE, 0x00, 0x02}, 3, 0x8000, 7, NULL},
        {"BNE not taken", {0xD0, 0x02}, 2, 0x8000, 2, setup_z_set},
        {"BNE taken", {0xD0, 0x02}, 2, 0x8000, 3, setup_z_clear},
        {"BNE taken cross", {0xD0, 0x10}, 2, 0x80FD, 4, setup_z_clear},
        {"JMP abs", {0x4C, 0x00, 0x90}, 3, 0x8000, 3, NULL},
        {"JMP (ind)", {0x6C, 0x00, 0x02}, 3, 0x8000, 5, setup_jmpind},
        {"JSR", {0x20, 0x00, 0x90}, 3, 0x8000, 6, NULL},
        {"RTS", {0x60}, 1, 0x8000, 6, setup_stack_rts},
        {"RTI", {0x40}, 1, 0x8000, 6, setup_stack_rti},
        {"PHA", {0x48}, 1, 0x8000, 3, setup_pha},
        {"PLA", {0x68}, 1, 0x8000, 4, NULL},
        {"BRK", {0x00}, 1, 0x8000, 7, NULL},
    };
    for (size_t i = 0; i < sizeof cases / sizeof cases[0]; i++) {
        uint64_t got = cycles_of(cases[i].code, cases[i].len, cases[i].org, cases[i].setup);
        CHECK((int)got == cases[i].expect, "%s: expected %d cycles, got %llu",
              cases[i].name, cases[i].expect, (unsigned long long)got);
    }
}

static void test_nmi_sequence(void) {
    static const uint8_t code[] = {0xEA, 0xEA};
    CPU c;
    Flat f;
    flat_setup(&c, &f, 0x8000, code, sizeof code);
    f.mem[0xFFFA] = 0x00;
    f.mem[0xFFFB] = 0x90;
    c.nmi = true;
    uint64_t before = c.cycles;
    cpu_step(&c);
    CHECK(c.cycles - before == 7, "NMI should take 7 cycles, took %llu",
          (unsigned long long)(c.cycles - before));
    CHECK(c.pc == 0x9000, "NMI vector not taken (pc=$%04X)", c.pc);
    CHECK((c.p & CPU_FLAG_I) != 0, "NMI should set I");
}

/* ---- iNES images ----------------------------------------------------------- */

/* Writes a minimal iNES file. prg_banks is in 16 KiB units, chr_banks in 8 KiB.
 * prg is the full PRG-ROM contents; chr may be NULL for CHR-RAM. */
static bool write_rom(const char *path, int mapper, int prg_banks, int chr_banks,
                      const uint8_t *prg, const uint8_t *chr, uint8_t flags7_extra) {
    FILE *f = fopen(path, "wb");
    if (!f) {
        return false;
    }
    uint8_t hdr[16] = {'N', 'E', 'S', 0x1A, (uint8_t)prg_banks, (uint8_t)chr_banks,
                       (uint8_t)((mapper & 0x0F) << 4), (uint8_t)((mapper & 0xF0) | flags7_extra)};
    fwrite(hdr, 1, sizeof hdr, f);
    fwrite(prg, 1, (size_t)prg_banks * 0x4000, f);
    if (chr_banks > 0) {
        fwrite(chr, 1, (size_t)chr_banks * 0x2000, f);
    }
    fclose(f);
    return true;
}

static void test_loader_rejects(void) {
    const char *path = "/tmp/nes_test_bad.nes";
    uint8_t prg[0x4000];
    memset(prg, 0, sizeof prg);

    write_rom(path, 5, 1, 0, prg, NULL, 0);
    char err[128];
    Cart *c = cart_load(path, err, sizeof err);
    CHECK(c == NULL, "unsupported mapper 5 should be rejected");

    /* NES 2.0 marker: flags7 bits 2-3 == 10 */
    write_rom(path, 0, 1, 0, prg, NULL, 0x08);
    c = cart_load(path, err, sizeof err);
    CHECK(c == NULL, "NES 2.0 header should be rejected");
    remove(path);
}

/* ---- mappers ---------------------------------------------------------------- */

static void test_mmc1_prg_bank(void) {
    const char *path = "/tmp/nes_test_mmc1.nes";
    uint8_t prg[4 * 0x4000];
    for (int b = 0; b < 4; b++) {
        memset(&prg[b * 0x4000], b + 1, 0x4000); /* bank b filled with b+1 */
    }
    write_rom(path, 1, 4, 0, prg, NULL, 0);
    char err[128];
    Cart *c = cart_load(path, err, sizeof err);
    CHECK(c != NULL, "MMC1 load failed: %s", err);
    if (!c) {
        remove(path);
        return;
    }
    /* Default PRG mode 3: $C000 fixed to last bank (4), $8000 switchable (1). */
    CHECK(cart_cpu_read(c, 0x8000) == 1, "MMC1 $8000 default bank expected 1");
    CHECK(cart_cpu_read(c, 0xC000) == 4, "MMC1 $C000 should be last bank");

    /* Serial write of value 2 into PRG register ($E000): 5 writes, LSB first. */
    uint8_t v = 2;
    for (int i = 0; i < 5; i++) {
        cart_cpu_write(c, 0xE000, (uint8_t)((v >> i) & 1));
    }
    CHECK(cart_cpu_read(c, 0x8000) == 3, "MMC1 bank 2 should appear at $8000 as bank index 3 (fill=3)");
    cart_free(c);
    remove(path);
}

static void test_mmc3_irq(void) {
    const char *path = "/tmp/nes_test_mmc3.nes";
    uint8_t prg[2 * 0x4000];
    memset(prg, 0, sizeof prg);
    uint8_t chr[0x2000];
    memset(chr, 0, sizeof chr);
    write_rom(path, 4, 2, 1, prg, chr, 0);
    char err[128];
    Cart *c = cart_load(path, err, sizeof err);
    CHECK(c != NULL, "MMC3 load failed: %s", err);
    if (!c) {
        remove(path);
        return;
    }
    cart_cpu_write(c, 0xC000, 2); /* latch = 2 */
    cart_cpu_write(c, 0xC001, 0); /* reload */
    cart_cpu_write(c, 0xE001, 0); /* enable IRQ */

    /* Four A12 rising edges, each preceded by a long low phase. */
    uint64_t t = 100;
    cart_ppu_addr(c, 0x0000, t);
    cart_ppu_addr(c, 0x1000, t + 100); /* clock 1: counter = latch (2) */
    cart_ppu_addr(c, 0x0000, t + 120);
    cart_ppu_addr(c, 0x1000, t + 140); /* clock 2: counter = 1 */
    CHECK(!cart_irq_pending(c), "IRQ should not fire after 2 clocks");
    cart_ppu_addr(c, 0x0000, t + 160);
    /* A short low gap (under the A12 filter) must not clock the counter. */
    cart_ppu_addr(c, 0x1000, t + 162);
    CHECK(!cart_irq_pending(c), "short A12 pulse must not clock the counter");
    cart_ppu_addr(c, 0x0000, t + 170);
    cart_ppu_addr(c, 0x1000, t + 180); /* clock 3: counter = 0 -> IRQ */
    CHECK(cart_irq_pending(c), "IRQ should fire on the third counted clock");
    cart_cpu_write(c, 0xE000, 0); /* disable + acknowledge */
    CHECK(!cart_irq_pending(c), "$E000 write should acknowledge IRQ");
    cart_free(c);
    remove(path);
}

/* ---- end-to-end boot -------------------------------------------------------- */

static void test_boot_and_palette(void) {
    const char *path = "/tmp/nes_test_boot.nes";
    uint8_t prg[0x4000];
    memset(prg, 0xEA, sizeof prg); /* NOP filler */
    static const uint8_t program[] = {
        0x78,                   /* 8000 SEI              */
        0xA9, 0x3F,             /* 8001 LDA #$3F         */
        0x8D, 0x06, 0x20,       /* 8003 STA $2006        */
        0xA9, 0x00,             /* 8006 LDA #$00         */
        0x8D, 0x06, 0x20,       /* 8008 STA $2006        */
        0xA9, 0x01,             /* 800B LDA #$01         */
        0x8D, 0x07, 0x20,       /* 800D STA $2007        */
        0xA9, 0x1E,             /* 8010 LDA #$1E         */
        0x8D, 0x01, 0x20,       /* 8012 STA $2001        */
        0xA9, 0x80,             /* 8015 LDA #$80         */
        0x8D, 0x00, 0x20,       /* 8017 STA $2000        */
        0x4C, 0x1A, 0x80,       /* 801A JMP self         */
    };
    memcpy(prg, program, sizeof program);
    prg[0x20] = 0x40;           /* 8020: RTI (NMI handler) */
    prg[0x3FFA] = 0x20;         /* NMI  -> $8020 */
    prg[0x3FFB] = 0x80;
    prg[0x3FFC] = 0x00;         /* RESET -> $8000 */
    prg[0x3FFD] = 0x80;
    prg[0x3FFE] = 0x00;         /* IRQ  -> $8000 (unused) */
    prg[0x3FFF] = 0x80;
    write_rom(path, 0, 1, 0, prg, NULL, 0);

    char err[128];
    Cart *cart = cart_load(path, err, sizeof err);
    CHECK(cart != NULL, "NROM load failed: %s", err);
    if (!cart) {
        remove(path);
        return;
    }
    Nes *nes = nes_new(cart, 44100.0, NULL, NULL);
    CHECK(nes != NULL, "nes_new failed");
    if (nes) {
        for (int i = 0; i < 3; i++) {
            nes_run_frame(nes);
        }
        const uint32_t *fb = nes_framebuffer(nes);
        CHECK(fb[0] == 0xFF001E74, "backdrop pixel expected $FF001E74, got $%08X", fb[0]);
        CHECK(fb[PPU_HEIGHT * PPU_WIDTH - 1] == 0xFF001E74, "last pixel backdrop mismatch");
        nes_free(nes);
    }
    cart_free(cart);
    remove(path);
}

/* ---- PPU sprites ------------------------------------------------------------ */

static void ppu_write_vram(PPU *p, uint16_t addr, const uint8_t *data, size_t n) {
    ppu_write_reg(p, 0x2006, (uint8_t)(addr >> 8));
    ppu_write_reg(p, 0x2006, (uint8_t)addr);
    for (size_t i = 0; i < n; i++) {
        ppu_write_reg(p, 0x2007, data[i]);
    }
}

/* Runs one frame and returns the status register as it stood just before the
 * pre-render line, where the hardware clears the sprite flags. */
static uint8_t run_ppu_frame(PPU *p) {
    while (!(p->scanline == 261 && p->dot == 0)) {
        ppu_step(p);
    }
    uint8_t status = p->status;
    for (int i = 0; i < 341; i++) {
        ppu_step(p);
    }
    return status;
}

static void test_ppu_sprites(void) {
    const char *path = "/tmp/nes_test_ppu.nes";
    uint8_t prg[0x4000];
    memset(prg, 0xEA, sizeof prg);
    write_rom(path, 0, 1, 0, prg, NULL, 0);
    char err[128];
    Cart *cart = cart_load(path, err, sizeof err);
    CHECK(cart != NULL, "PPU test cart load failed: %s", err);
    if (!cart) {
        remove(path);
        return;
    }

    static PPU ppu;
    ppu_init(&ppu, cart);

    /* Tiles 0 and 1: every pixel is colour index 1 (opaque). */
    uint8_t tile[32];
    memset(tile, 0, sizeof tile);
    memset(tile, 0xFF, 8);
    memset(&tile[16], 0xFF, 8);
    ppu_write_vram(&ppu, 0x0000, tile, sizeof tile);

    uint8_t bg1 = 0x16, spr1 = 0x12;
    ppu_write_vram(&ppu, 0x3F01, &bg1, 1);  /* background palette 0, colour 1 */
    ppu_write_vram(&ppu, 0x3F11, &spr1, 1); /* sprite palette 0, colour 1 */
    ppu_write_reg(&ppu, 0x2006, 0);         /* v = t = 0 */
    ppu_write_reg(&ppu, 0x2006, 0);
    ppu_write_reg(&ppu, 0x2000, 0);

    /* One sprite: Y=39 (shows on lines 40-47), tile 1, X=16. */
    memset(ppu.oam, 0xFF, sizeof ppu.oam);
    ppu.oam[0] = 39;
    ppu.oam[1] = 1;
    ppu.oam[2] = 0;
    ppu.oam[3] = 16;
    ppu_write_reg(&ppu, 0x2001, 0x1E);

    const uint32_t bg_colour = 0xFF982220;     /* nes_palette[0x16] */
    const uint32_t spr_colour = 0xFF3032EC;    /* nes_palette[0x12] */

    uint8_t status = run_ppu_frame(&ppu);
    CHECK(ppu.framebuffer[40 * 256 + 16] == spr_colour,
          "sprite pixel in front expected $%08X, got $%08X", spr_colour, ppu.framebuffer[40 * 256 + 16]);
    CHECK(ppu.framebuffer[40 * 256 + 15] == bg_colour, "background left of sprite wrong");
    CHECK(ppu.framebuffer[41 * 256 + 23] == spr_colour, "sprite right edge wrong");
    CHECK(ppu.framebuffer[41 * 256 + 24] == bg_colour, "background right of sprite wrong");
    CHECK((status & 0x40) != 0, "sprite 0 hit should be set over opaque background");

    /* Same sprite behind the background: background colour wins. */
    ppu.oam[2] = 0x20;
    run_ppu_frame(&ppu);
    CHECK(ppu.framebuffer[40 * 256 + 16] == bg_colour, "behind-background sprite should be hidden");

    /* Nine sprites on one line: overflow flag. */
    memset(ppu.oam, 0xFF, sizeof ppu.oam);
    for (int i = 0; i < 9; i++) {
        ppu.oam[i * 4 + 0] = 99;
        ppu.oam[i * 4 + 1] = 1;
        ppu.oam[i * 4 + 2] = 0;
        ppu.oam[i * 4 + 3] = (uint8_t)(i * 16);
    }
    status = run_ppu_frame(&ppu);
    CHECK((status & 0x20) != 0, "nine sprites on a line should set overflow");

    cart_free(cart);
    remove(path);
}

int main(void) {
    test_ppu_sprites();
    test_program_subroutine_loop();
    test_flags_and_bcd_free_adc_sbc();
    test_indexed_and_shifts();
    test_undocumented_lax_sax();
    test_cycle_counts();
    test_nmi_sequence();
    test_loader_rejects();
    test_mmc1_prg_bank();
    test_mmc3_irq();
    test_boot_and_palette();

    printf("%d checks, %d failures\n", checks, failures);
    return failures ? 1 : 0;
}
