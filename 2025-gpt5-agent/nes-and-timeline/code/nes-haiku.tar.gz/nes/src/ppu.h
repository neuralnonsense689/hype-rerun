/* 2C02 PPU: dot-driven background/sprite pipeline with scanline sprite evaluation. */
#ifndef NES_PPU_H
#define NES_PPU_H

#include <stdbool.h>
#include <stdint.h>

#include "cart.h"

#define PPU_WIDTH 256
#define PPU_HEIGHT 240

typedef struct PPU {
    Cart *cart;

    /* CPU-visible registers */
    uint8_t ctrl;        /* $2000 */
    uint8_t mask;        /* $2001 */
    uint8_t status;      /* $2002 */
    uint8_t oam_addr;    /* $2003 */
    uint8_t oam[256];
    uint8_t read_buf;    /* $2007 read buffer */

    /* Internal loopy registers */
    uint16_t v;          /* current VRAM address */
    uint16_t t;          /* temporary VRAM address */
    uint8_t fine_x;
    bool w;              /* write toggle for $2005/$2006 */

    /* Memory */
    uint8_t vram[4096];  /* 2 KiB CIRAM, plus 2 KiB for four-screen boards */
    uint8_t palette[32];

    /* Timing */
    int scanline;        /* -1 .. 261 mapped as 0..261 with 261 = pre-render */
    int dot;             /* 0..340 */
    bool odd_frame;
    uint64_t clock;      /* PPU cycles since power-on (A12 filter timing) */
    bool suppress_vbl;   /* $2002 read on the VBL set dot suppresses it */
    bool nmi_pending;
    bool frame_done;

    /* Background pipeline */
    uint8_t nt_latch, at_latch, bg_lo_latch, bg_hi_latch;
    uint16_t bg_shift_lo, bg_shift_hi;
    uint16_t attr_shift_lo, attr_shift_hi;

    /* Sprites for the current scanline (filled for the next one at dot 257) */
    uint8_t sec_oam[32];
    int spr_count;
    bool spr0_line;      /* secondary slot 0 holds OAM sprite 0 */
    uint8_t spr_x[8], spr_attr[8], spr_lo[8], spr_hi[8];

    uint32_t framebuffer[PPU_WIDTH * PPU_HEIGHT]; /* 0xAARRGGBB */
} PPU;

void ppu_init(PPU *p, Cart *cart);
void ppu_reset(PPU *p);

/* CPU register access, addr in $2000-$3FFF (mirrors handled internally). */
uint8_t ppu_read_reg(PPU *p, uint16_t addr);
void ppu_write_reg(PPU *p, uint16_t addr, uint8_t value);

/* OAM DMA target: writes one byte at OAMADDR and increments it. */
void ppu_oam_dma_write(PPU *p, uint8_t value);

/* Advances the PPU by one PPU cycle (3 per CPU cycle on NTSC). */
void ppu_step(PPU *p);

/* Returns true once per NMI edge. */
bool ppu_take_nmi(PPU *p);

/* Returns true once per completed frame. */
bool ppu_take_frame(PPU *p);

#endif
