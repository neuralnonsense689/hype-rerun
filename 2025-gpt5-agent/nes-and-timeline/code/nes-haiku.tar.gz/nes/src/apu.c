/* 2A03 APU implementation. Timing is per CPU cycle; pulse and noise timers
 * tick every other CPU cycle, the triangle and DMC timers every cycle. */
#include "apu.h"

#include <string.h>

static const uint8_t length_table[32] = {
    10, 254, 20, 2, 40, 4, 80, 6, 160, 8, 60, 10, 14, 12, 26, 14,
    12, 16, 24, 18, 48, 20, 96, 22, 192, 24, 72, 26, 16, 28, 32, 30,
};

static const uint8_t duty_table[4][8] = {
    {0, 1, 0, 0, 0, 0, 0, 0},
    {0, 1, 1, 0, 0, 0, 0, 0},
    {0, 1, 1, 1, 1, 0, 0, 0},
    {1, 0, 0, 1, 1, 1, 1, 1},
};

static const uint8_t triangle_table[32] = {
    15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
};

static const uint16_t noise_period_table[16] = {
    4, 8, 16, 32, 64, 96, 128, 160, 202, 254, 380, 508, 762, 1016, 2034, 4068,
};

static const uint16_t dmc_rate_table[16] = {
    428, 380, 340, 320, 286, 254, 226, 214, 190, 160, 142, 128, 106, 84, 72, 54,
};

/* Frame counter step points, in CPU cycles (NTSC). */
#define FC_STEP1 3729
#define FC_STEP2 7457
#define FC_STEP3 11186
#define FC_STEP4 14915
#define FC_STEP5 18641

/* ---- units ---------------------------------------------------------------- */

static void envelope_clock(ApuEnvelope *e) {
    if (e->start) {
        e->start = false;
        e->decay = 15;
        e->divider = e->period;
    } else if (e->divider == 0) {
        e->divider = e->period;
        if (e->decay > 0) {
            e->decay--;
        } else if (e->loop) {
            e->decay = 15;
        }
    } else {
        e->divider--;
    }
}

static uint8_t envelope_volume(const ApuEnvelope *e) {
    return e->constant ? e->period : e->decay;
}

static uint16_t pulse_target_period(const ApuPulse *p, bool ones_complement_quirk) {
    uint16_t change = p->timer_period >> p->sweep_shift;
    if (p->sweep_negate) {
        return (uint16_t)(p->timer_period - change - (ones_complement_quirk ? 1 : 0));
    }
    return (uint16_t)(p->timer_period + change);
}

static bool pulse_muted(const ApuPulse *p, bool quirk) {
    return p->timer_period < 8 || pulse_target_period(p, quirk) > 0x7FF;
}

static void sweep_clock(ApuPulse *p, bool quirk) {
    if (p->sweep_divider == 0 && p->sweep_enabled && p->sweep_shift > 0 && !pulse_muted(p, quirk)) {
        p->timer_period = pulse_target_period(p, quirk);
    }
    if (p->sweep_divider == 0 || p->sweep_reload) {
        p->sweep_divider = p->sweep_period;
        p->sweep_reload = false;
    } else {
        p->sweep_divider--;
    }
}

static void pulse_timer_clock(ApuPulse *p) {
    if (p->timer == 0) {
        p->timer = p->timer_period;
        p->seq_pos = (uint8_t)((p->seq_pos + 1) & 7);
    } else {
        p->timer--;
    }
}

static uint8_t pulse_output(const ApuPulse *p, bool quirk) {
    if (!p->enabled || p->length == 0 || pulse_muted(p, quirk)) {
        return 0;
    }
    if (!duty_table[p->duty][p->seq_pos]) {
        return 0;
    }
    return envelope_volume(&p->env);
}

static void length_clock(uint8_t *len, bool halt) {
    if (!halt && *len > 0) {
        (*len)--;
    }
}

static void triangle_timer_clock(ApuTriangle *t) {
    if (t->timer == 0) {
        t->timer = t->timer_period;
        if (t->length > 0 && t->linear > 0) {
            t->seq_pos = (uint8_t)((t->seq_pos + 1) & 31);
        }
    } else {
        t->timer--;
    }
}

static void noise_timer_clock(ApuNoise *n) {
    if (n->timer == 0) {
        n->timer = n->timer_period;
        uint16_t other = n->mode ? ((n->lfsr >> 6) & 1) : ((n->lfsr >> 1) & 1);
        uint16_t feedback = (n->lfsr & 1) ^ other;
        n->lfsr = (uint16_t)((n->lfsr >> 1) | (feedback << 14));
    } else {
        n->timer--;
    }
}

static uint8_t noise_output(const ApuNoise *n) {
    if (!n->enabled || n->length == 0 || (n->lfsr & 1)) {
        return 0;
    }
    return envelope_volume(&n->env);
}

static void dmc_fetch_sample(APU *a) {
    ApuDmc *d = &a->dmc;
    if (d->buffer_empty && d->bytes_remaining > 0 && a->mem_read) {
        d->buffer = a->mem_read(a->mem_ctx, d->cur_addr);
        d->buffer_empty = false;
        d->cur_addr = (d->cur_addr == 0xFFFF) ? 0x8000 : (uint16_t)(d->cur_addr + 1);
        d->bytes_remaining--;
        if (d->bytes_remaining == 0) {
            if (d->loop) {
                d->cur_addr = d->sample_addr;
                d->bytes_remaining = d->sample_length;
            } else if (d->irq_enabled) {
                d->irq = true;
            }
        }
    }
}

static void dmc_timer_clock(APU *a) {
    ApuDmc *d = &a->dmc;
    if (d->timer == 0) {
        d->timer = d->timer_period;
        if (!d->silence) {
            if (d->shift & 1) {
                if (d->level <= 125) {
                    d->level += 2;
                }
            } else if (d->level >= 2) {
                d->level -= 2;
            }
        }
        d->shift >>= 1;
        if (d->bits_remaining > 0) {
            d->bits_remaining--;
        }
        if (d->bits_remaining == 0) {
            d->bits_remaining = 8;
            if (d->buffer_empty) {
                d->silence = true;
            } else {
                d->silence = false;
                d->shift = d->buffer;
                d->buffer_empty = true;
                dmc_fetch_sample(a);
            }
        }
    } else {
        d->timer--;
    }
}

/* ---- frame counter ------------------------------------------------------- */

static void clock_quarter(APU *a) {
    for (int i = 0; i < 2; i++) {
        ApuPulse *p = &a->pulse[i];
        envelope_clock(&p->env);
    }
    envelope_clock(&a->noise.env);

    ApuTriangle *t = &a->tri;
    if (t->linear_reload_flag) {
        t->linear = t->linear_reload;
    } else if (t->linear > 0) {
        t->linear--;
    }
    if (!t->control) {
        t->linear_reload_flag = false;
    }
}

static void clock_half(APU *a) {
    clock_quarter(a);
    for (int i = 0; i < 2; i++) {
        ApuPulse *p = &a->pulse[i];
        length_clock(&p->length, p->halt);
        sweep_clock(p, i == 0);
    }
    length_clock(&a->tri.length, a->tri.control);
    length_clock(&a->noise.length, a->noise.halt);
}

static void frame_counter_step(APU *a) {
    uint32_t c = a->frame_cycle;
    if (!a->five_step) {
        if (c == FC_STEP1 || c == FC_STEP3) {
            clock_quarter(a);
        } else if (c == FC_STEP2) {
            clock_half(a);
        } else if (c == FC_STEP4) {
            clock_half(a);
            if (!a->irq_inhibit) {
                a->frame_irq = true;
            }
            a->frame_cycle = 0;
        }
    } else {
        if (c == FC_STEP1 || c == FC_STEP3) {
            clock_quarter(a);
        } else if (c == FC_STEP2) {
            clock_half(a);
        } else if (c == FC_STEP5) {
            clock_half(a);
            a->frame_cycle = 0;
        }
    }
}

/* ---- public API ---------------------------------------------------------- */

void apu_init(APU *a, double sample_rate, double cpu_hz,
              ApuSampleSink sink, void *sink_ctx,
              ApuMemRead mem_read, void *mem_ctx) {
    memset(a, 0, sizeof *a);
    a->sample_period_cycles = cpu_hz / sample_rate;
    a->sink = sink;
    a->sink_ctx = sink_ctx;
    a->mem_read = mem_read;
    a->mem_ctx = mem_ctx;
    apu_reset(a);
}

void apu_reset(APU *a) {
    ApuSampleSink sink = a->sink;
    void *sink_ctx = a->sink_ctx;
    ApuMemRead mem_read = a->mem_read;
    void *mem_ctx = a->mem_ctx;
    double period = a->sample_period_cycles;
    memset(a, 0, sizeof *a);
    a->sink = sink;
    a->sink_ctx = sink_ctx;
    a->mem_read = mem_read;
    a->mem_ctx = mem_ctx;
    a->sample_period_cycles = period;
    a->noise.lfsr = 1;
    a->dmc.buffer_empty = true;
    a->dmc.silence = true;
    a->dmc.bits_remaining = 8;
    apu_write(a, 0x4015, 0);
    apu_write(a, 0x4017, 0);
}

void apu_write(APU *a, uint16_t addr, uint8_t value) {
    switch (addr) {
    /* Pulse 1 / 2 */
    case 0x4000: case 0x4004: {
        ApuPulse *p = &a->pulse[(addr >> 2) & 1];
        p->duty = value >> 6;
        p->halt = (value & 0x20) != 0;
        p->env.loop = p->halt;
        p->env.constant = (value & 0x10) != 0;
        p->env.period = value & 0x0F;
        break;
    }
    case 0x4001: case 0x4005: {
        ApuPulse *p = &a->pulse[(addr >> 2) & 1];
        p->sweep_enabled = (value & 0x80) != 0;
        p->sweep_period = (value >> 4) & 7;
        p->sweep_negate = (value & 0x08) != 0;
        p->sweep_shift = value & 7;
        p->sweep_reload = true;
        break;
    }
    case 0x4002: case 0x4006: {
        ApuPulse *p = &a->pulse[(addr >> 2) & 1];
        p->timer_period = (uint16_t)((p->timer_period & 0x700) | value);
        break;
    }
    case 0x4003: case 0x4007: {
        ApuPulse *p = &a->pulse[(addr >> 2) & 1];
        p->timer_period = (uint16_t)((p->timer_period & 0x00FF) | ((value & 7) << 8));
        if (p->enabled) {
            p->length = length_table[value >> 3];
        }
        p->env.start = true;
        p->seq_pos = 0;
        break;
    }

    /* Triangle */
    case 0x4008:
        a->tri.control = (value & 0x80) != 0;
        a->tri.linear_reload = value & 0x7F;
        break;
    case 0x400A:
        a->tri.timer_period = (uint16_t)((a->tri.timer_period & 0x700) | value);
        break;
    case 0x400B:
        a->tri.timer_period = (uint16_t)((a->tri.timer_period & 0x00FF) | ((value & 7) << 8));
        if (a->tri.enabled) {
            a->tri.length = length_table[value >> 3];
        }
        a->tri.linear_reload_flag = true;
        break;

    /* Noise */
    case 0x400C:
        a->noise.halt = (value & 0x20) != 0;
        a->noise.env.loop = a->noise.halt;
        a->noise.env.constant = (value & 0x10) != 0;
        a->noise.env.period = value & 0x0F;
        break;
    case 0x400E:
        a->noise.mode = (value & 0x80) != 0;
        a->noise.timer_period = noise_period_table[value & 0x0F];
        break;
    case 0x400F:
        if (a->noise.enabled) {
            a->noise.length = length_table[value >> 3];
        }
        a->noise.env.start = true;
        break;

    /* DMC */
    case 0x4010:
        a->dmc.irq_enabled = (value & 0x80) != 0;
        a->dmc.loop = (value & 0x40) != 0;
        a->dmc.timer_period = dmc_rate_table[value & 0x0F];
        if (!a->dmc.irq_enabled) {
            a->dmc.irq = false;
        }
        break;
    case 0x4011:
        a->dmc.level = value & 0x7F;
        break;
    case 0x4012:
        a->dmc.sample_addr = (uint16_t)(0xC000 + value * 64);
        break;
    case 0x4013:
        a->dmc.sample_length = (uint16_t)(value * 16 + 1);
        break;

    /* Status / enables */
    case 0x4015:
        a->pulse[0].enabled = (value & 0x01) != 0;
        a->pulse[1].enabled = (value & 0x02) != 0;
        a->tri.enabled = (value & 0x04) != 0;
        a->noise.enabled = (value & 0x08) != 0;
        if (!a->pulse[0].enabled) a->pulse[0].length = 0;
        if (!a->pulse[1].enabled) a->pulse[1].length = 0;
        if (!a->tri.enabled) a->tri.length = 0;
        if (!a->noise.enabled) a->noise.length = 0;
        a->dmc.enabled = (value & 0x10) != 0;
        a->dmc.irq = false;
        if (!a->dmc.enabled) {
            a->dmc.bytes_remaining = 0;
        } else if (a->dmc.bytes_remaining == 0) {
            a->dmc.cur_addr = a->dmc.sample_addr;
            a->dmc.bytes_remaining = a->dmc.sample_length;
            dmc_fetch_sample(a);
        }
        break;

    /* Frame counter */
    case 0x4017:
        a->five_step = (value & 0x80) != 0;
        a->irq_inhibit = (value & 0x40) != 0;
        if (a->irq_inhibit) {
            a->frame_irq = false;
        }
        a->frame_reset_delay = a->odd_cycle ? 4 : 3;
        break;

    default:
        break;
    }
}

uint8_t apu_read_status(APU *a) {
    uint8_t v = 0;
    if (a->pulse[0].length > 0) v |= 0x01;
    if (a->pulse[1].length > 0) v |= 0x02;
    if (a->tri.length > 0) v |= 0x04;
    if (a->noise.length > 0) v |= 0x08;
    if (a->dmc.bytes_remaining > 0) v |= 0x10;
    if (a->frame_irq) v |= 0x40;
    if (a->dmc.irq) v |= 0x80;
    a->frame_irq = false;
    return v;
}

bool apu_irq(const APU *a) {
    return a->frame_irq || a->dmc.irq;
}

static float mix(const APU *a) {
    /* Nonlinear mixer from the NESdev wiki approximation. */
    uint8_t p1 = pulse_output(&a->pulse[0], true);
    uint8_t p2 = pulse_output(&a->pulse[1], false);
    uint8_t t = a->tri.enabled ? triangle_table[a->tri.seq_pos] : 0;
    uint8_t n = noise_output(&a->noise);
    uint8_t d = a->dmc.level;

    double pulse_out = 0.0;
    if (p1 + p2 > 0) {
        pulse_out = 95.88 / (8128.0 / (p1 + p2) + 100.0);
    }
    double tnd_sum = t / 8227.0 + n / 12241.0 + d / 22638.0;
    double tnd_out = 0.0;
    if (tnd_sum > 0.0) {
        tnd_out = 159.79 / (1.0 / tnd_sum + 100.0);
    }
    return (float)(pulse_out + tnd_out); /* roughly 0.0 .. 1.0 */
}

void apu_step(APU *a) {
    /* Frame counter: may be reset by a pending $4017 write. */
    if (a->frame_reset_delay > 0) {
        if (--a->frame_reset_delay == 0) {
            a->frame_cycle = 0;
            if (a->five_step) {
                clock_half(a);
            }
        }
    } else {
        a->frame_cycle++;
        frame_counter_step(a);
    }

    /* Timers. */
    triangle_timer_clock(&a->tri);
    dmc_timer_clock(a);
    if (!a->odd_cycle) {
        pulse_timer_clock(&a->pulse[0]);
        pulse_timer_clock(&a->pulse[1]);
        noise_timer_clock(&a->noise);
    }
    a->odd_cycle = !a->odd_cycle;

    /* Downsample with a box average over the output period. */
    a->mix_sum += mix(a);
    a->mix_count++;
    a->sample_acc += 1.0;
    if (a->sample_acc >= a->sample_period_cycles) {
        a->sample_acc -= a->sample_period_cycles;
        double avg = a->mix_sum / a->mix_count;
        a->mix_sum = 0.0;
        a->mix_count = 0;

        /* One-pole high-pass (~37 Hz at 44.1 kHz) removes DC from the mix. */
        double out = avg * 2.0 - 0.5;
        double hp = 0.995 * (a->hp_prev_out + out - a->hp_prev_in);
        a->hp_prev_in = out;
        a->hp_prev_out = hp;

        double s = hp * 16000.0;
        if (s > 32767.0) s = 32767.0;
        if (s < -32768.0) s = -32768.0;
        if (a->sink) {
            a->sink(a->sink_ctx, (int16_t)s);
        }
    }
}
