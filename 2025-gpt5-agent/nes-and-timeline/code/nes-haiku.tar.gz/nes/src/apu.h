/* 2A03 APU: pulse x2, triangle, noise, DMC, frame counter, nonlinear mixer.
 * Produces samples at a fixed host rate through a sink callback. */
#ifndef NES_APU_H
#define NES_APU_H

#include <stdbool.h>
#include <stdint.h>

/* Receives one mixed sample per output period. */
typedef void (*ApuSampleSink)(void *ctx, int16_t sample);
/* Reads CPU memory for DMC sample fetches (no cycle cost is modelled). */
typedef uint8_t (*ApuMemRead)(void *ctx, uint16_t addr);

typedef struct ApuEnvelope {
    bool start;
    bool loop;
    bool constant;
    uint8_t period;     /* volume or envelope period */
    uint8_t divider;
    uint8_t decay;
} ApuEnvelope;

typedef struct ApuPulse {
    bool enabled;
    uint8_t duty;
    uint8_t length;
    bool halt;          /* also envelope loop */
    ApuEnvelope env;
    /* sweep */
    bool sweep_enabled;
    bool sweep_negate;
    bool sweep_reload;
    bool sweep_ones_complement; /* pulse 1 quirk */
    uint8_t sweep_period;
    uint8_t sweep_divider;
    uint8_t sweep_shift;
    /* timer / sequencer */
    uint16_t timer_period;
    uint16_t timer;
    uint8_t seq_pos;
} ApuPulse;

typedef struct ApuTriangle {
    bool enabled;
    uint8_t length;
    bool control;      /* halt flag and linear counter reload disable */
    uint8_t linear_reload;
    uint8_t linear;
    bool linear_reload_flag;
    uint16_t timer_period;
    uint16_t timer;
    uint8_t seq_pos;
} ApuTriangle;

typedef struct ApuNoise {
    bool enabled;
    uint8_t length;
    bool halt;
    ApuEnvelope env;
    bool mode;          /* short (93-step) LFSR mode */
    uint16_t timer_period;
    uint16_t timer;
    uint16_t lfsr;
} ApuNoise;

typedef struct ApuDmc {
    bool enabled;
    bool irq_enabled;
    bool loop;
    uint16_t timer_period;
    uint16_t timer;
    uint8_t level;
    uint16_t sample_addr;
    uint16_t sample_length;
    uint16_t cur_addr;
    uint16_t bytes_remaining;
    uint8_t buffer;
    bool buffer_empty;
    uint8_t shift;
    uint8_t bits_remaining;
    bool silence;
    bool irq;
} ApuDmc;

typedef struct APU {
    ApuPulse pulse[2];
    ApuTriangle tri;
    ApuNoise noise;
    ApuDmc dmc;

    bool five_step;
    bool irq_inhibit;
    bool frame_irq;
    uint32_t frame_cycle;
    int frame_reset_delay;   /* cycles until a $4017 write takes effect; 0 = idle */
    bool odd_cycle;

    /* Output */
    double sample_period_cycles;  /* CPU cycles per output sample */
    double sample_acc;
    double mix_sum;
    int mix_count;
    double hp_prev_in;      /* DC-blocking high-pass state */
    double hp_prev_out;

    ApuSampleSink sink;
    void *sink_ctx;
    ApuMemRead mem_read;
    void *mem_ctx;
} APU;

/* sample_rate: host output rate in Hz. cpu_hz: CPU clock (NTSC 1789773). */
void apu_init(APU *a, double sample_rate, double cpu_hz,
              ApuSampleSink sink, void *sink_ctx,
              ApuMemRead mem_read, void *mem_ctx);
void apu_reset(APU *a);

/* Register writes for $4000-$4013, $4015, $4017. */
void apu_write(APU *a, uint16_t addr, uint8_t value);
/* $4015 read. Clears the frame interrupt flag. */
uint8_t apu_read_status(APU *a);

/* Advances the APU by one CPU cycle. */
void apu_step(APU *a);

/* Combined APU IRQ line (frame counter or DMC). */
bool apu_irq(const APU *a);

#endif
