/* Internal cartridge state shared by cart.c and mappers.c. Not for other modules. */
#ifndef NES_CART_INTERNAL_H
#define NES_CART_INTERNAL_H

#include "cart.h"

#define PRG_BANK_8K 0x2000u
#define CHR_BANK_1K 0x0400u

typedef struct Cart Cart;
typedef struct MapperOps MapperOps;

struct MapperOps {
    void (*reset)(Cart *c);
    /* Write to $8000-$FFFF (register space). Already bus-conflict-filtered if needed. */
    void (*write)(Cart *c, uint16_t addr, uint8_t value);
    /* PPU A12 observer (MMC3). May be NULL. */
    void (*ppu_addr)(Cart *c, uint16_t addr, uint64_t ppu_clock);
};

struct Cart {
    int mapper;
    Mirror mirror;          /* current mirroring (mapper may change it) */
    Mirror header_mirror;   /* mirroring from header; used when mapper does not control it */
    bool battery;
    bool pal;
    bool has_trainer;       /* informational only; trainer is skipped on load */
    bool chr_is_ram;

    uint8_t *prg_rom;
    size_t prg_size;        /* multiple of 16 KiB, > 0 */
    uint8_t *chr;
    size_t chr_size;        /* multiple of 8 KiB, > 0 (8 KiB RAM if header says 0) */
    uint8_t prg_ram[0x2000];

    /* Bank maps. prg_map[i]: byte offset into prg_rom for the 8 KiB window at
     * $8000 + i*0x2000. chr_map[i]: byte offset into chr for the 1 KiB window at
     * i*0x400. The CPU/PPU accessors only use these, so mappers just rewrite them. */
    size_t prg_map[4];
    size_t chr_map[8];

    const MapperOps *ops;
    int variant;            /* mapper-specific flag, e.g. mapper 180 */

    /* Generic mapper registers (interpreted per mapper). */
    uint8_t regs[8];
    uint8_t shift;          /* MMC1 serial shift register */
    uint8_t shift_count;

    /* MMC3 */
    uint8_t bank_select;
    uint8_t bank_regs[8];
    bool irq_enabled;
    bool irq_line;
    bool irq_reload;
    uint8_t irq_latch;
    uint8_t irq_counter;
    bool a12_high;
    uint64_t a12_low_since; /* ppu_clock when A12 last went low */
};

/* Mapper constructor table. Returns NULL for unsupported mapper numbers. */
const MapperOps *mapper_ops_for(int mapper_id, int *variant);

/* Bank helpers used by mapper implementations. */
void cart_set_prg_8k(Cart *c, int slot, size_t bank);
void cart_set_chr_1k(Cart *c, int slot, size_t bank);

#endif
