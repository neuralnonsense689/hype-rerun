/* SDL2 audio output: a ring buffer drained by the SDL audio callback.
 * The emulator stages samples through audio_sink() and publishes them with
 * audio_commit(); the emulator is paced by audio_queued(). */
#ifndef NES_AUDIO_OUT_H
#define NES_AUDIO_OUT_H

#include <stddef.h>
#include <stdint.h>

typedef struct AudioOut AudioOut;

/* Opens a mono S16 device at the requested rate. Returns NULL on failure. */
AudioOut *audio_open(int requested_rate);
void audio_close(AudioOut *a);

/* Actual device sample rate. */
int audio_rate(const AudioOut *a);

/* ApuSampleSink-compatible: stages one sample. ctx may be NULL. */
void audio_sink(void *ctx, int16_t sample);

/* Moves staged samples into the playback ring. */
void audio_commit(AudioOut *a);

/* Samples currently waiting in the playback ring. */
size_t audio_queued(AudioOut *a);

#endif
