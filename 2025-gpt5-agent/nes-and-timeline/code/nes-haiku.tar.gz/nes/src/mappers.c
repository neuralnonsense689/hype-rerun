/* Mapper implementations: 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM), 4 (MMC3),
 * plus 180 (UNROM-style with fixed $8000 bank). Each mapper only rewrites the
 * bank maps in Cart; the bus accessors in cart.c do the actual lookups. */
#include "cart_internal.h"

#include <stddef.h>

static size_t prg_banks_8k(const Cart *c) { return c->prg_size / PRG_BANK_8K; }
static size_t prg_banks_16k(const Cart *c) { return c->prg_size / 0x4000u; }

/* Map a 16 KiB PRG bank into the two 8 KiB windows starting at 'slot'. */
static void prg_16k(Cart *c, int slot, size_t bank16) {
    cart_set_prg_8k(c, slot, bank16 * 2);
    cart_set_prg_8k(c, slot + 1, bank16 * 2 + 1);
}

/* Bus conflict: the written value is ANDed with the ROM byte at that address. */
static uint8_t conflict(Cart *c, uint16_t addr, uint8_t value) {
    return value & cart_cpu_read(c, addr);
}

/* ------------------------------------------------------------------------- */
/* Mapper 0 (NROM): no registers. Defaults in cart_reset already fit 16/32 KiB. */

static const MapperOps ops_nrom = {NULL, NULL, NULL};

/* ------------------------------------------------------------------------- */
/* Mapper 180: fixed first 16 KiB at $8000, switchable 16 KiB at $C000. */

static void m180_reset(Cart *c) {
    prg_16k(c, 0, 0);
    prg_16k(c, 2, 0);
}

static void m180_write(Cart *c, uint16_t addr, uint8_t value) {
    (void)addr;
    prg_16k(c, 2, value & 0x07);
}

static const MapperOps ops_180 = {m180_reset, m180_write, NULL};

/* ------------------------------------------------------------------------- */
/* Mapper 2 (UxROM): switchable 16 KiB at $8000, last 16 KiB fixed at $C000. */

static void uxrom_reset(Cart *c) {
    prg_16k(c, 0, 0);
    prg_16k(c, 2, prg_banks_16k(c) - 1);
}

static void uxrom_write(Cart *c, uint16_t addr, uint8_t value) {
    value = conflict(c, addr, value);
    prg_16k(c, 0, value & 0x0F);
}

static const MapperOps ops_uxrom = {uxrom_reset, uxrom_write, NULL};

/* ------------------------------------------------------------------------- */
/* Mapper 3 (CNROM): switchable 8 KiB CHR bank, PRG fixed like NROM. */

static void cnrom_write(Cart *c, uint16_t addr, uint8_t value) {
    value = conflict(c, addr, value);
    size_t base = (size_t)(value & 0x03) * 8;
    for (int i = 0; i < 8; i++) {
        cart_set_chr_1k(c, i, base + (size_t)i);
    }
}

static const MapperOps ops_cnrom = {NULL, cnrom_write, NULL};

/* ------------------------------------------------------------------------- */
/* Mapper 1 (MMC1 / SxROM). Serial 5-bit writes select one of four registers. */

static void mmc1_apply(Cart *c) {
    uint8_t ctl = c->regs[0];

    if (c->header_mirror == MIRROR_FOUR_SCREEN) {
        c->mirror = MIRROR_FOUR_SCREEN;
    } else {
        switch (ctl & 0x03) {
        case 0: c->mirror = MIRROR_SINGLE_LOW; break;
        case 1: c->mirror = MIRROR_SINGLE_HIGH; break;
        case 2: c->mirror = MIRROR_VERTICAL; break;
        default: c->mirror = MIRROR_HORIZONTAL; break;
        }
    }

    size_t n8 = prg_banks_8k(c);
    size_t prg = c->regs[3] & 0x0F;
    switch ((ctl >> 2) & 0x03) {
    case 0:
    case 1: /* 32 KiB mode */
        for (int i = 0; i < 4; i++) {
            cart_set_prg_8k(c, i, (prg & 0x0E) + (size_t)i);
        }
        break;
    case 2: /* first bank fixed at $8000, switch $C000 */
        cart_set_prg_8k(c, 0, 0);
        cart_set_prg_8k(c, 1, 1);
        prg_16k(c, 2, prg);
        break;
    default: /* switch $8000, last bank fixed at $C000 */
        prg_16k(c, 0, prg);
        cart_set_prg_8k(c, 2, n8 - 2);
        cart_set_prg_8k(c, 3, n8 - 1);
        break;
    }

    if (ctl & 0x10) { /* two independent 4 KiB CHR banks */
        for (int i = 0; i < 4; i++) {
            cart_set_chr_1k(c, i, (size_t)c->regs[1] * 4 + (size_t)i);
            cart_set_chr_1k(c, 4 + i, (size_t)c->regs[2] * 4 + (size_t)i);
        }
    } else { /* one 8 KiB CHR bank; low bit of chr0 ignored */
        size_t base = ((size_t)c->regs[1] & 0x1E) * 4;
        for (int i = 0; i < 8; i++) {
            cart_set_chr_1k(c, i, base + (size_t)i);
        }
    }
}

static void mmc1_reset(Cart *c) {
    c->regs[0] = 0x0C; /* PRG mode 3: last bank fixed at $C000 */
    c->shift = 0;
    c->shift_count = 0;
    mmc1_apply(c);
}

static void mmc1_write(Cart *c, uint16_t addr, uint8_t value) {
    if (value & 0x80) {
        c->shift = 0;
        c->shift_count = 0;
        c->regs[0] |= 0x0C;
        mmc1_apply(c);
        return;
    }
    c->shift = (uint8_t)((c->shift >> 1) | ((value & 1) << 4));
    if (++c->shift_count == 5) {
        unsigned target = (addr >> 13) & 0x03; /* $8000,$A000,$C000,$E000 */
        c->regs[target] = c->shift & 0x1F;
        c->shift = 0;
        c->shift_count = 0;
        mmc1_apply(c);
    }
}

static const MapperOps ops_mmc1 = {mmc1_reset, mmc1_write, NULL};

/* ------------------------------------------------------------------------- */
/* Mapper 4 (MMC3): 8 bank registers, scanline IRQ clocked by PPU A12 rises. */

static void mmc3_apply(Cart *c) {
    size_t n8 = prg_banks_8k(c);
    bool prg_mode1 = (c->bank_select & 0x40) != 0;
    bool chr_inv = (c->bank_select & 0x80) != 0;

    if (prg_mode1) {
        cart_set_prg_8k(c, 0, n8 - 2);
        cart_set_prg_8k(c, 2, c->bank_regs[6]);
    } else {
        cart_set_prg_8k(c, 0, c->bank_regs[6]);
        cart_set_prg_8k(c, 2, n8 - 2);
    }
    cart_set_prg_8k(c, 1, c->bank_regs[7]);
    cart_set_prg_8k(c, 3, n8 - 1);

    size_t r0 = c->bank_regs[0] & 0xFE;
    size_t r1 = c->bank_regs[1] & 0xFE;
    if (chr_inv) {
        for (int i = 0; i < 4; i++) {
            cart_set_chr_1k(c, i, c->bank_regs[2 + i]);
        }
        cart_set_chr_1k(c, 4, r0);
        cart_set_chr_1k(c, 5, r0 + 1);
        cart_set_chr_1k(c, 6, r1);
        cart_set_chr_1k(c, 7, r1 + 1);
    } else {
        cart_set_chr_1k(c, 0, r0);
        cart_set_chr_1k(c, 1, r0 + 1);
        cart_set_chr_1k(c, 2, r1);
        cart_set_chr_1k(c, 3, r1 + 1);
        for (int i = 0; i < 4; i++) {
            cart_set_chr_1k(c, 4 + i, c->bank_regs[2 + i]);
        }
    }
}

static void mmc3_reset(Cart *c) {
    c->bank_select = 0;
    for (int i = 0; i < 8; i++) {
        c->bank_regs[i] = 0;
    }
    mmc3_apply(c);
}

static void mmc3_write(Cart *c, uint16_t addr, uint8_t value) {
    switch (addr & 0xE001) {
    case 0x8000:
        c->bank_select = value;
        mmc3_apply(c);
        break;
    case 0x8001:
        c->bank_regs[c->bank_select & 0x07] = value;
        mmc3_apply(c);
        break;
    case 0xA000:
        if (c->header_mirror != MIRROR_FOUR_SCREEN) {
            c->mirror = (value & 1) ? MIRROR_HORIZONTAL : MIRROR_VERTICAL;
        }
        break;
    case 0xA001:
        break; /* PRG-RAM protect: RAM is always enabled here */
    case 0xC000:
        c->irq_latch = value;
        break;
    case 0xC001:
        c->irq_counter = 0;
        c->irq_reload = true;
        break;
    case 0xE000:
        c->irq_enabled = false;
        c->irq_line = false;
        break;
    default: /* 0xE001 */
        c->irq_enabled = true;
        break;
    }
}

/* A12 must be low for a few CPU cycles before a rise counts; this filters the
 * short low gaps between sprite pattern fetches. Threshold in PPU cycles. */
#define MMC3_A12_FILTER 9

static void mmc3_ppu_addr(Cart *c, uint16_t addr, uint64_t clock) {
    bool high = (addr & 0x1000) != 0;
    if (!high) {
        if (c->a12_high) {
            c->a12_low_since = clock;
        }
        c->a12_high = false;
        return;
    }
    if (c->a12_high) {
        return;
    }
    c->a12_high = true;
    if (clock - c->a12_low_since < MMC3_A12_FILTER) {
        return;
    }
    /* Scanline counter clock. */
    if (c->irq_counter == 0 || c->irq_reload) {
        c->irq_counter = c->irq_latch;
    } else {
        c->irq_counter--;
    }
    c->irq_reload = false;
    if (c->irq_counter == 0 && c->irq_enabled) {
        c->irq_line = true;
    }
}

static const MapperOps ops_mmc3 = {mmc3_reset, mmc3_write, mmc3_ppu_addr};

/* ------------------------------------------------------------------------- */

const MapperOps *mapper_ops_for(int mapper_id, int *variant) {
    *variant = 0;
    switch (mapper_id) {
    case 0: return &ops_nrom;
    case 1: return &ops_mmc1;
    case 2: return &ops_uxrom;
    case 3: return &ops_cnrom;
    case 4: return &ops_mmc3;
    case 180: *variant = 180; return &ops_180;
    default: return NULL;
    }
}
