/* Ricoh 2A03 CPU core (MOS 6502 without decimal mode).
 *
 * Every memory access goes through the bus callbacks and costs one CPU cycle;
 * the bus is responsible for advancing the PPU/APU by that cycle. This gives
 * cycle-accurate instruction timing, including dummy reads and page-cross
 * penalties. */
#ifndef NES_CPU_H
#define NES_CPU_H

#include <stdbool.h>
#include <stdint.h>

typedef struct CpuBus {
    uint8_t (*read)(void *ctx, uint16_t addr);
    void (*write)(void *ctx, uint16_t addr, uint8_t value);
    void *ctx;
} CpuBus;

typedef struct CPU {
    uint8_t a, x, y, s, p;
    uint16_t pc;
    bool nmi;          /* NMI edge latched by the owner; serviced at next step */
    bool irq;          /* IRQ line level, set by the owner before each step */
    bool jammed;       /* KIL opcode executed; CPU only idles until reset */
    uint64_t cycles;   /* total CPU cycles executed */
    CpuBus bus;
    bool trace_unknown; /* print a message once for undocumented NOP-like opcodes */
} CPU;

void cpu_init(CPU *c, CpuBus bus);
void cpu_reset(CPU *c);

/* Executes one instruction, or one interrupt sequence if one is pending. */
void cpu_step(CPU *c);

/* Processor status bits. */
enum {
    CPU_FLAG_C = 0x01,
    CPU_FLAG_Z = 0x02,
    CPU_FLAG_I = 0x04,
    CPU_FLAG_D = 0x08,
    CPU_FLAG_B = 0x10,
    CPU_FLAG_U = 0x20,
    CPU_FLAG_V = 0x40,
    CPU_FLAG_N = 0x80,
};

#endif
