/* NES system: wires the CPU, PPU, APU, work RAM, controllers and cartridge. */
#ifndef NES_NES_H
#define NES_NES_H

#include <stdbool.h>
#include <stdint.h>

#include "apu.h"
#include "cart.h"

/* Button bits for nes_set_buttons(). Same order as the controller shift register. */
enum {
    NES_BTN_A = 0x01,
    NES_BTN_B = 0x02,
    NES_BTN_SELECT = 0x04,
    NES_BTN_START = 0x08,
    NES_BTN_UP = 0x10,
    NES_BTN_DOWN = 0x20,
    NES_BTN_LEFT = 0x40,
    NES_BTN_RIGHT = 0x80,
};

typedef struct Nes Nes;

/* The cartridge is borrowed; the caller frees it after nes_free(). */
Nes *nes_new(Cart *cart, double audio_rate, ApuSampleSink sink, void *sink_ctx);
void nes_free(Nes *n);
void nes_reset(Nes *n);

/* port: 0 or 1. */
void nes_set_buttons(Nes *n, int port, uint8_t buttons);

/* Runs the CPU/PPU/APU until the next frame is complete (about 1/60 s NTSC). */
void nes_run_frame(Nes *n);

/* 256x240 framebuffer in 0xAARRGGBB. */
const uint32_t *nes_framebuffer(const Nes *n);

Cart *nes_cart(Nes *n);

#endif
