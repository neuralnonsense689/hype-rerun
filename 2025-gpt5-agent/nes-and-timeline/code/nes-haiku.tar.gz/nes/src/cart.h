/* Cartridge: iNES 1.0 loader, PRG/CHR storage, mapper dispatch, battery SRAM. */
#ifndef NES_CART_H
#define NES_CART_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef enum {
    MIRROR_HORIZONTAL,
    MIRROR_VERTICAL,
    MIRROR_SINGLE_LOW,
    MIRROR_SINGLE_HIGH,
    MIRROR_FOUR_SCREEN
} Mirror;

typedef struct Cart Cart;

/* Loads an iNES 1.0 file. Returns NULL and fills err on failure. */
Cart *cart_load(const char *path, char *err, size_t errlen);
void cart_free(Cart *c);

/* Reset the mapper (cartridge reset line). */
void cart_reset(Cart *c);

/* CPU bus side: addresses $4020-$FFFF. */
uint8_t cart_cpu_read(Cart *c, uint16_t addr);
void cart_cpu_write(Cart *c, uint16_t addr, uint8_t value);

/* PPU bus side: pattern tables $0000-$1FFF. */
uint8_t cart_ppu_read(Cart *c, uint16_t addr);
void cart_ppu_write(Cart *c, uint16_t addr, uint8_t value);

/* Called by the PPU on every VRAM address drive, for A12-clocked mappers
 * (MMC3). ppu_clock is a monotonically increasing PPU cycle count. */
void cart_ppu_addr(Cart *c, uint16_t addr, uint64_t ppu_clock);

/* Current nametable mirroring (may change at runtime on MMC1/MMC3). */
Mirror cart_mirror(const Cart *c);

/* Mapper IRQ line (MMC3). */
bool cart_irq_pending(const Cart *c);
void cart_irq_ack(Cart *c);

/* Battery-backed PRG-RAM persistence: writes/reads the .sav file. */
bool cart_has_battery(const Cart *c);
bool cart_save_sram(const Cart *c, const char *path);
bool cart_load_sram(Cart *c, const char *path);

/* Metadata */
int cart_mapper_id(const Cart *c);
bool cart_is_pal(const Cart *c);

#endif
