/* SDL2 audio output. The SDL callback thread drains the ring; the emulation
 * thread appends to it under SDL_LockAudioDevice. */
#include "audio_out.h"

#include <SDL.h>
#include <stdlib.h>
#include <string.h>

#define RING_CAP 16384u  /* samples; power of two not required */
#define STAGE_CAP 8192u  /* more than one frame of output at any rate we use */

struct AudioOut {
    SDL_AudioDeviceID dev;
    int rate;
    int16_t ring[RING_CAP];
    size_t head;   /* next sample to read */
    size_t count;  /* samples in ring */
    int16_t stage[STAGE_CAP];
    size_t stage_n;
};

static void fill_callback(void *userdata, Uint8 *stream, int len) {
    AudioOut *a = userdata;
    int16_t *out = (int16_t *)stream;
    int n = len / (int)sizeof(int16_t);
    for (int i = 0; i < n; i++) {
        if (a->count > 0) {
            out[i] = a->ring[a->head];
            a->head = (a->head + 1) % RING_CAP;
            a->count--;
        } else {
            out[i] = 0; /* underrun: play silence */
        }
    }
}

AudioOut *audio_open(int requested_rate) {
    if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0) {
        return NULL;
    }
    AudioOut *a = calloc(1, sizeof *a);
    if (!a) {
        return NULL;
    }
    SDL_AudioSpec want, have;
    memset(&want, 0, sizeof want);
    want.freq = requested_rate;
    want.format = AUDIO_S16SYS;
    want.channels = 1;
    want.samples = 512;
    want.callback = fill_callback;
    want.userdata = a;

    a->dev = SDL_OpenAudioDevice(NULL, 0, &want, &have, 0);
    if (a->dev == 0) {
        free(a);
        return NULL;
    }
    a->rate = have.freq;
    SDL_PauseAudioDevice(a->dev, 0);
    return a;
}

void audio_close(AudioOut *a) {
    if (!a) {
        return;
    }
    SDL_CloseAudioDevice(a->dev);
    free(a);
}

int audio_rate(const AudioOut *a) {
    return a->rate;
}

void audio_sink(void *ctx, int16_t sample) {
    AudioOut *a = ctx;
    if (a && a->stage_n < STAGE_CAP) {
        a->stage[a->stage_n++] = sample;
    }
}

void audio_commit(AudioOut *a) {
    SDL_LockAudioDevice(a->dev);
    for (size_t i = 0; i < a->stage_n; i++) {
        if (a->count < RING_CAP) {
            a->ring[(a->head + a->count) % RING_CAP] = a->stage[i];
            a->count++;
        }
    }
    SDL_UnlockAudioDevice(a->dev);
    a->stage_n = 0;
}

size_t audio_queued(AudioOut *a) {
    SDL_LockAudioDevice(a->dev);
    size_t n = a->count;
    SDL_UnlockAudioDevice(a->dev);
    return n;
}
