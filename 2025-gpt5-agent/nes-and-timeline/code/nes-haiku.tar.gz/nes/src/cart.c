/* Cartridge: iNES 1.0 parsing, bus accessors, battery save files. */
#include "cart_internal.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void set_err(char *err, size_t errlen, const char *msg) {
    if (err && errlen) {
        snprintf(err, errlen, "%s", msg);
    }
}

void cart_set_prg_8k(Cart *c, int slot, size_t bank) {
    size_t n = c->prg_size / PRG_BANK_8K;
    c->prg_map[slot] = (bank % n) * PRG_BANK_8K;
}

void cart_set_chr_1k(Cart *c, int slot, size_t bank) {
    size_t n = c->chr_size / CHR_BANK_1K;
    c->chr_map[slot] = (bank % n) * CHR_BANK_1K;
}

Cart *cart_load(const char *path, char *err, size_t errlen) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        set_err(err, errlen, "cannot open ROM file");
        return NULL;
    }
    uint8_t hdr[16];
    if (fread(hdr, 1, sizeof hdr, f) != sizeof hdr) {
        set_err(err, errlen, "file too short for iNES header");
        fclose(f);
        return NULL;
    }
    if (memcmp(hdr, "NES\x1A", 4) != 0) {
        set_err(err, errlen, "not an iNES file (bad magic)");
        fclose(f);
        return NULL;
    }
    if ((hdr[7] & 0x0C) == 0x08) {
        set_err(err, errlen, "NES 2.0 format is not supported");
        fclose(f);
        return NULL;
    }

    size_t prg_banks = hdr[4];
    size_t chr_banks = hdr[5];
    if (prg_banks == 0) {
        set_err(err, errlen, "header declares zero PRG-ROM banks");
        fclose(f);
        return NULL;
    }

    Cart *c = calloc(1, sizeof *c);
    if (!c) {
        set_err(err, errlen, "out of memory");
        fclose(f);
        return NULL;
    }

    uint8_t flags6 = hdr[6];
    uint8_t flags7 = hdr[7];
    c->mapper = (flags6 >> 4) | (flags7 & 0xF0);
    c->battery = (flags6 & 0x02) != 0;
    c->has_trainer = (flags6 & 0x04) != 0;
    c->pal = (hdr[9] & 0x01) != 0;
    if (flags6 & 0x08) {
        c->header_mirror = MIRROR_FOUR_SCREEN;
    } else {
        c->header_mirror = (flags6 & 0x01) ? MIRROR_VERTICAL : MIRROR_HORIZONTAL;
    }
    c->mirror = c->header_mirror;

    c->ops = mapper_ops_for(c->mapper, &c->variant);
    if (!c->ops) {
        char buf[96];
        snprintf(buf, sizeof buf, "unsupported mapper %d", c->mapper);
        set_err(err, errlen, buf);
        free(c);
        fclose(f);
        return NULL;
    }

    if (c->has_trainer && fseek(f, 512, SEEK_CUR) != 0) {
        set_err(err, errlen, "truncated trainer");
        goto fail;
    }

    c->prg_size = prg_banks * 0x4000u;
    c->prg_rom = malloc(c->prg_size);
    if (!c->prg_rom || fread(c->prg_rom, 1, c->prg_size, f) != c->prg_size) {
        set_err(err, errlen, "truncated PRG-ROM");
        goto fail;
    }

    if (chr_banks == 0) {
        c->chr_is_ram = true;
        c->chr_size = 0x2000;
    } else {
        c->chr_size = chr_banks * 0x2000u;
    }
    c->chr = calloc(1, c->chr_size);
    if (!c->chr) {
        set_err(err, errlen, "out of memory");
        goto fail;
    }
    if (!c->chr_is_ram && fread(c->chr, 1, c->chr_size, f) != c->chr_size) {
        set_err(err, errlen, "truncated CHR-ROM");
        goto fail;
    }

    fclose(f);
    cart_reset(c);
    return c;

fail:
    fclose(f);
    cart_free(c);
    return NULL;
}

void cart_free(Cart *c) {
    if (!c) {
        return;
    }
    free(c->prg_rom);
    free(c->chr);
    free(c);
}

void cart_reset(Cart *c) {
    memset(c->regs, 0, sizeof c->regs);
    c->shift = 0;
    c->shift_count = 0;
    c->bank_select = 0;
    memset(c->bank_regs, 0, sizeof c->bank_regs);
    c->irq_enabled = false;
    c->irq_line = false;
    c->irq_reload = false;
    c->irq_latch = 0;
    c->irq_counter = 0;
    c->a12_high = false;
    c->a12_low_since = 0;
    c->mirror = c->header_mirror;
    /* Default bank layout; mapper reset may override it. */
    for (int i = 0; i < 4; i++) {
        cart_set_prg_8k(c, i, (size_t)i); /* wraps for 16 KiB PRG (NROM-128) */
    }
    for (int i = 0; i < 8; i++) {
        cart_set_chr_1k(c, i, (size_t)i);
    }
    if (c->ops->reset) {
        c->ops->reset(c);
    }
}

uint8_t cart_cpu_read(Cart *c, uint16_t addr) {
    if (addr >= 0x8000) {
        size_t off = c->prg_map[(addr - 0x8000) >> 13] + (addr & 0x1FFF);
        return c->prg_rom[off];
    }
    if (addr >= 0x6000) {
        return c->prg_ram[addr - 0x6000];
    }
    return 0; /* $4020-$5FFF: no expansion hardware; open bus not modelled */
}

void cart_cpu_write(Cart *c, uint16_t addr, uint8_t value) {
    if (addr >= 0x8000) {
        if (c->ops->write) {
            c->ops->write(c, addr, value);
        }
    } else if (addr >= 0x6000) {
        c->prg_ram[addr - 0x6000] = value;
    }
}

uint8_t cart_ppu_read(Cart *c, uint16_t addr) {
    addr &= 0x1FFF;
    return c->chr[c->chr_map[addr >> 10] + (addr & 0x3FF)];
}

void cart_ppu_write(Cart *c, uint16_t addr, uint8_t value) {
    if (!c->chr_is_ram) {
        return;
    }
    addr &= 0x1FFF;
    c->chr[c->chr_map[addr >> 10] + (addr & 0x3FF)] = value;
}

void cart_ppu_addr(Cart *c, uint16_t addr, uint64_t ppu_clock) {
    if (c->ops->ppu_addr) {
        c->ops->ppu_addr(c, addr, ppu_clock);
    }
}

Mirror cart_mirror(const Cart *c) {
    return c->mirror;
}

bool cart_irq_pending(const Cart *c) {
    return c->irq_line;
}

void cart_irq_ack(Cart *c) {
    c->irq_line = false;
}

bool cart_has_battery(const Cart *c) {
    return c->battery;
}

bool cart_save_sram(const Cart *c, const char *path) {
    if (!c->battery) {
        return false;
    }
    FILE *f = fopen(path, "wb");
    if (!f) {
        return false;
    }
    bool ok = fwrite(c->prg_ram, 1, sizeof c->prg_ram, f) == sizeof c->prg_ram;
    return fclose(f) == 0 && ok;
}

bool cart_load_sram(Cart *c, const char *path) {
    if (!c->battery) {
        return false;
    }
    FILE *f = fopen(path, "rb");
    if (!f) {
        return false;
    }
    size_t n = fread(c->prg_ram, 1, sizeof c->prg_ram, f);
    fclose(f);
    return n == sizeof c->prg_ram;
}

int cart_mapper_id(const Cart *c) {
    return c->mapper;
}

bool cart_is_pal(const Cart *c) {
    return c->pal;
}
