/* 2C02 PPU implementation.
 *
 * Background: standard loopy v/t/x scrolling with 16-bit shift registers,
 * fetched in 8-dot groups (NT, AT, pattern low, pattern high).
 * Sprites: secondary OAM is evaluated once per scanline at dot 257 for the
 * following scanline; pattern fetches for dots 257-320 are issued at their real
 * addresses so the cartridge (MMC3 A12 counter) sees the same bus activity.
 */
#include "ppu.h"

#include <string.h>

#define CTRL_NMI 0x80
#define CTRL_SPR_8X16 0x20
#define CTRL_BG_TABLE 0x10
#define CTRL_SPR_TABLE 0x08
#define CTRL_INC32 0x04

#define MASK_GRAY 0x01
#define MASK_BG_LEFT 0x02
#define MASK_SPR_LEFT 0x04
#define MASK_BG 0x08
#define MASK_SPR 0x10

#define ST_OVERFLOW 0x20
#define ST_SPR0 0x40
#define ST_VBLANK 0x80

#define LAST_DOT 340
#define PRERENDER_LINE 261

/* 2C02 master palette (NTSC), 0xAARRGGBB. */
static const uint32_t nes_palette[64] = {
    0xFF545454, 0xFF001E74, 0xFF081090, 0xFF300088, 0xFF440064, 0xFF5C0030, 0xFF540400, 0xFF3C1800,
    0xFF202A00, 0xFF083A00, 0xFF004000, 0xFF003C00, 0xFF003232, 0xFF000000, 0xFF000000, 0xFF000000,
    0xFF989698, 0xFF084CC4, 0xFF3032EC, 0xFF5C1EE4, 0xFF8814B4, 0xFFA01464, 0xFF982220, 0xFF783C00,
    0xFF545A00, 0xFF287200, 0xFF087C00, 0xFF007628, 0xFF006678, 0xFF000000, 0xFF000000, 0xFF000000,
    0xFFECEEEC, 0xFF4C9AEC, 0xFF787CEC, 0xFFA062EC, 0xFFDC54EC, 0xFFEC58B4, 0xFFEC6A64, 0xFFD48820,
    0xFFA0AA00, 0xFF74C400, 0xFF4CD020, 0xFF38CC6C, 0xFF38B4CC, 0xFF3C3C3C, 0xFF000000, 0xFF000000,
    0xFFECEEEC, 0xFFA8CCEC, 0xFFBCBCEC, 0xFFD4B2EC, 0xFFECAEEC, 0xFFECAED4, 0xFFECB4B0, 0xFFE4C490,
    0xFFCCD278, 0xFFB4DE78, 0xFFA8E290, 0xFF98E2B4, 0xFFA0D6E4, 0xFFA0A2A0, 0xFF000000, 0xFF000000,
};

/* ---- memory ------------------------------------------------------------- */

static uint16_t palette_index(uint16_t addr) {
    uint16_t a = addr & 0x1F;
    if ((a & 0x13) == 0x10) {
        a &= 0x0F; /* $3F10/14/18/1C mirror $3F00/04/08/0C */
    }
    return a;
}

/* Maps a nametable address ($2000-$2FFF) to an offset into p->vram. */
static uint16_t nametable_offset(Mirror m, uint16_t addr) {
    uint16_t table = (addr >> 10) & 0x03;
    uint16_t off = addr & 0x03FF;
    switch (m) {
    case MIRROR_HORIZONTAL: return (uint16_t)((table >> 1) * 0x400 + off);
    case MIRROR_VERTICAL: return (uint16_t)((table & 1) * 0x400 + off);
    case MIRROR_SINGLE_LOW: return off;
    case MIRROR_SINGLE_HIGH: return (uint16_t)(0x400 + off);
    default: return (uint16_t)(table * 0x400 + off); /* four-screen */
    }
}

static uint8_t vram_read(PPU *p, uint16_t addr) {
    addr &= 0x3FFF;
    if (addr < 0x3F00) {
        cart_ppu_addr(p->cart, addr, p->clock);
    }
    if (addr < 0x2000) {
        return cart_ppu_read(p->cart, addr);
    }
    if (addr < 0x3F00) {
        return p->vram[nametable_offset(cart_mirror(p->cart), addr & 0x2FFF)];
    }
    return p->palette[palette_index(addr)];
}

static void vram_write(PPU *p, uint16_t addr, uint8_t value) {
    addr &= 0x3FFF;
    if (addr < 0x3F00) {
        cart_ppu_addr(p->cart, addr, p->clock);
    }
    if (addr < 0x2000) {
        cart_ppu_write(p->cart, addr, value);
    } else if (addr < 0x3F00) {
        p->vram[nametable_offset(cart_mirror(p->cart), addr & 0x2FFF)] = value;
    } else {
        p->palette[palette_index(addr)] = value & 0x3F;
    }
}

/* ---- loopy register helpers -------------------------------------------- */

static bool rendering_enabled(const PPU *p) {
    return (p->mask & (MASK_BG | MASK_SPR)) != 0;
}

static void inc_coarse_x(PPU *p) {
    if ((p->v & 0x001F) == 31) {
        p->v &= ~0x001F;
        p->v ^= 0x0400;
    } else {
        p->v++;
    }
}

static void inc_fine_y(PPU *p) {
    if ((p->v & 0x7000) != 0x7000) {
        p->v += 0x1000;
        return;
    }
    p->v &= ~0x7000;
    uint16_t y = (p->v & 0x03E0) >> 5;
    if (y == 29) {
        y = 0;
        p->v ^= 0x0800;
    } else if (y == 31) {
        y = 0;
    } else {
        y++;
    }
    p->v = (uint16_t)((p->v & ~0x03E0) | (y << 5));
}

static void transfer_x(PPU *p) {
    p->v = (uint16_t)((p->v & ~0x041F) | (p->t & 0x041F));
}

static void transfer_y(PPU *p) {
    p->v = (uint16_t)((p->v & ~0x7BE0) | (p->t & 0x7BE0));
}

/* ---- background fetch pipeline ----------------------------------------- */

/* Loads the latched tile into the low byte of each shifter. The attribute
 * bit is replicated across the whole byte so every pixel of the tile sees it. */
static void load_bg_shifters(PPU *p) {
    p->bg_shift_lo = (uint16_t)((p->bg_shift_lo & 0xFF00) | p->bg_lo_latch);
    p->bg_shift_hi = (uint16_t)((p->bg_shift_hi & 0xFF00) | p->bg_hi_latch);
    p->attr_shift_lo = (uint16_t)((p->attr_shift_lo & 0xFF00) | ((p->at_latch & 1) ? 0xFF : 0x00));
    p->attr_shift_hi = (uint16_t)((p->attr_shift_hi & 0xFF00) | ((p->at_latch & 2) ? 0xFF : 0x00));
}

static void shift_bg(PPU *p) {
    p->bg_shift_lo <<= 1;
    p->bg_shift_hi <<= 1;
    p->attr_shift_lo <<= 1;
    p->attr_shift_hi <<= 1;
}

static uint16_t pattern_address(PPU *p, uint8_t tile, int fine_row) {
    uint16_t base = (p->ctrl & CTRL_BG_TABLE) ? 0x1000 : 0x0000;
    return (uint16_t)(base + tile * 16 + fine_row);
}

static void fetch_bg_step(PPU *p) {
    switch ((p->dot - 1) & 7) {
    case 0:
        load_bg_shifters(p);
        p->nt_latch = vram_read(p, 0x2000 | (p->v & 0x0FFF));
        break;
    case 2: {
        uint16_t a = 0x23C0 | (p->v & 0x0C00) | ((p->v >> 4) & 0x38) | ((p->v >> 2) & 0x07);
        uint8_t at = vram_read(p, a);
        if (p->v & 0x40) {
            at >>= 4; /* bottom half of the attribute byte */
        }
        if (p->v & 0x02) {
            at >>= 2; /* right half */
        }
        p->at_latch = at & 0x03;
        break;
    }
    case 4:
        p->bg_lo_latch = vram_read(p, pattern_address(p, p->nt_latch, (p->v >> 12) & 7));
        break;
    case 6:
        p->bg_hi_latch = vram_read(p, pattern_address(p, p->nt_latch, ((p->v >> 12) & 7) + 8));
        break;
    case 7:
        inc_coarse_x(p);
        break;
    default:
        break;
    }
}

/* ---- sprites ------------------------------------------------------------ */

/* Secondary OAM evaluation for scanline 'line'. Sets spr_count, spr0_line,
 * and overflow. Runs once per scanline. */
static void evaluate_sprites(PPU *p, int line) {
    int height = (p->ctrl & CTRL_SPR_8X16) ? 16 : 8;
    p->spr_count = 0;
    p->spr0_line = false;
    for (int n = 0; n < 64; n++) {
        int row = line - (p->oam[n * 4] + 1);
        if (row < 0 || row >= height) {
            continue;
        }
        if (p->spr_count == 8) {
            p->status |= ST_OVERFLOW;
            break;
        }
        if (n == 0) {
            p->spr0_line = true;
        }
        memcpy(&p->sec_oam[p->spr_count * 4], &p->oam[n * 4], 4);
        p->spr_count++;
    }
}

/* Pattern address for secondary slot i on scanline 'line'. Empty slots fetch
 * tile $FF, as the hardware does, so the bus activity stays the same. */
static uint16_t sprite_pattern_address(PPU *p, int i, int line, int fine_plane) {
    uint8_t tile, attr;
    int y, row;
    if (i < p->spr_count) {
        y = p->sec_oam[i * 4];
        tile = p->sec_oam[i * 4 + 1];
        attr = p->sec_oam[i * 4 + 2];
    } else {
        y = line - 1; /* dummy sprite whose row is 0 on this line */
        tile = 0xFF;
        attr = 0;
    }
    row = line - (y + 1);
    if (p->ctrl & CTRL_SPR_8X16) {
        uint16_t base = (tile & 1) ? 0x1000 : 0x0000;
        tile &= 0xFE;
        if (attr & 0x80) {
            row = 15 - row;
        }
        if (row >= 8) {
            tile++;
            row -= 8;
        }
        return (uint16_t)(base + tile * 16 + row + fine_plane);
    }
    uint16_t base = (p->ctrl & CTRL_SPR_TABLE) ? 0x1000 : 0x0000;
    if (attr & 0x80) {
        row = 7 - row;
    }
    return (uint16_t)(base + tile * 16 + row + fine_plane);
}

/* Dots 257-320: fetch the eight sprite slots (garbage NT, AT, pattern lo/hi). */
static void fetch_sprite_step(PPU *p) {
    int slot = (p->dot - 257) >> 3;
    int step = (p->dot - 257) & 7;
    int line = (p->scanline == PRERENDER_LINE) ? 0 : p->scanline + 1;
    switch (step) {
    case 0:
        vram_read(p, 0x2000 | (p->v & 0x0FFF)); /* garbage nametable */
        break;
    case 2:
        vram_read(p, 0x23C0 | (p->v & 0x0C00)); /* garbage attribute */
        break;
    case 4:
        p->spr_lo[slot] = slot < p->spr_count ? vram_read(p, sprite_pattern_address(p, slot, line, 0)) : 0;
        if (slot < p->spr_count) {
            p->spr_x[slot] = p->sec_oam[slot * 4 + 3];
            p->spr_attr[slot] = p->sec_oam[slot * 4 + 2];
        } else {
            vram_read(p, sprite_pattern_address(p, slot, line, 0));
        }
        break;
    case 6:
        if (slot < p->spr_count) {
            p->spr_hi[slot] = vram_read(p, sprite_pattern_address(p, slot, line, 8));
        } else {
            p->spr_hi[slot] = 0;
            vram_read(p, sprite_pattern_address(p, slot, line, 8));
        }
        break;
    default:
        break;
    }
}

/* ---- pixel output -------------------------------------------------------- */

static void render_pixel(PPU *p) {
    int x = p->dot - 1;
    int y = p->scanline;
    uint8_t mask = p->mask;

    uint8_t bg_pix = 0, bg_pal = 0;
    if ((mask & MASK_BG) && (x >= 8 || (mask & MASK_BG_LEFT))) {
        uint16_t bit = (uint16_t)(0x8000 >> p->fine_x);
        bg_pix = (uint8_t)(((p->bg_shift_lo & bit) ? 1 : 0) | ((p->bg_shift_hi & bit) ? 2 : 0));
        bg_pal = (uint8_t)(((p->attr_shift_lo & bit) ? 1 : 0) | ((p->attr_shift_hi & bit) ? 2 : 0));
    }

    uint8_t spr_pix = 0, spr_pal = 0;
    bool spr_front = false;
    bool s0_opaque = false;
    if ((mask & MASK_SPR) && (x >= 8 || (mask & MASK_SPR_LEFT))) {
        for (int i = 0; i < p->spr_count; i++) {
            int off = x - p->spr_x[i];
            if (off < 0 || off > 7) {
                continue;
            }
            int bit = (p->spr_attr[i] & 0x40) ? off : 7 - off;
            uint8_t pix = (uint8_t)(((p->spr_lo[i] >> bit) & 1) | (((p->spr_hi[i] >> bit) & 1) << 1));
            if (pix == 0) {
                continue;
            }
            if (i == 0 && p->spr0_line) {
                s0_opaque = true;
            }
            if (spr_pix == 0) {
                spr_pix = pix;
                spr_pal = (uint8_t)(p->spr_attr[i] & 0x03);
                spr_front = (p->spr_attr[i] & 0x20) == 0;
            }
        }
    }

    /* Sprite 0 hit: opaque sprite-0 pixel over opaque background, not at x=255. */
    if (s0_opaque && bg_pix != 0 && x != 255 && !(p->status & ST_SPR0)) {
        p->status |= ST_SPR0;
    }

    uint8_t pal_idx;
    if (bg_pix == 0 && spr_pix == 0) {
        pal_idx = 0;
    } else if (bg_pix == 0) {
        pal_idx = (uint8_t)(0x10 + spr_pal * 4 + spr_pix);
    } else if (spr_pix == 0 || !spr_front) {
        pal_idx = (uint8_t)(bg_pal * 4 + bg_pix); /* background wins */
    } else {
        pal_idx = (uint8_t)(0x10 + spr_pal * 4 + spr_pix); /* sprite in front */
    }

    uint8_t color = p->palette[palette_index(pal_idx)];
    if (mask & MASK_GRAY) {
        color &= 0x30;
    }
    p->framebuffer[y * PPU_WIDTH + x] = nes_palette[color & 0x3F];
}

/* ---- public API ---------------------------------------------------------- */

void ppu_init(PPU *p, Cart *cart) {
    memset(p, 0, sizeof *p);
    p->cart = cart;
    ppu_reset(p);
}

void ppu_reset(PPU *p) {
    p->ctrl = 0;
    p->mask = 0;
    p->status = 0;
    p->w = false;
    p->fine_x = 0;
    p->read_buf = 0;
    p->scanline = 0;
    p->dot = 0;
    p->odd_frame = false;
    p->nmi_pending = false;
    p->frame_done = false;
    p->suppress_vbl = false;
}

uint8_t ppu_read_reg(PPU *p, uint16_t addr) {
    switch (addr & 7) {
    case 2: {
        uint8_t v = (uint8_t)((p->status & 0xE0) | (p->read_buf & 0x1F));
        if (p->scanline == 241 && p->dot <= 2) {
            p->suppress_vbl = true;
        }
        p->status &= (uint8_t)~ST_VBLANK;
        p->w = false;
        return v;
    }
    case 4:
        return p->oam[p->oam_addr];
    case 7: {
        uint16_t a = p->v & 0x3FFF;
        uint8_t v;
        if (a < 0x3F00) {
            v = p->read_buf;
            p->read_buf = vram_read(p, a);
        } else {
            v = vram_read(p, a);
            p->read_buf = vram_read(p, a - 0x1000);
        }
        p->v = (uint16_t)(p->v + ((p->ctrl & CTRL_INC32) ? 32 : 1));
        return v;
    }
    default:
        return 0; /* write-only registers read back as open bus; not modelled */
    }
}

void ppu_write_reg(PPU *p, uint16_t addr, uint8_t value) {
    switch (addr & 7) {
    case 0: {
        bool was_nmi = (p->ctrl & CTRL_NMI) != 0;
        p->ctrl = value;
        p->t = (uint16_t)((p->t & 0xF3FF) | ((value & 0x03) << 10));
        if (!was_nmi && (value & CTRL_NMI) && (p->status & ST_VBLANK)) {
            p->nmi_pending = true;
        }
        break;
    }
    case 1:
        p->mask = value;
        break;
    case 3:
        p->oam_addr = value;
        break;
    case 4:
        p->oam[p->oam_addr++] = value;
        break;
    case 5:
        if (!p->w) {
            p->fine_x = value & 0x07;
            p->t = (uint16_t)((p->t & ~0x001F) | (value >> 3));
        } else {
            p->t = (uint16_t)((p->t & 0x0C1F) | ((value & 0x07) << 12) | ((value & 0xF8) << 2));
        }
        p->w = !p->w;
        break;
    case 6:
        if (!p->w) {
            p->t = (uint16_t)((p->t & 0x00FF) | ((value & 0x3F) << 8));
        } else {
            p->t = (uint16_t)((p->t & 0x7F00) | value);
            p->v = p->t;
        }
        p->w = !p->w;
        break;
    case 7:
        vram_write(p, p->v, value);
        p->v = (uint16_t)(p->v + ((p->ctrl & CTRL_INC32) ? 32 : 1));
        break;
    default:
        break;
    }
}

void ppu_oam_dma_write(PPU *p, uint8_t value) {
    p->oam[p->oam_addr++] = value;
}

void ppu_step(PPU *p) {
    p->clock++;
    int line = p->scanline;
    int dot = p->dot;
    bool rendering = rendering_enabled(p);

    if (line < PPU_HEIGHT || line == PRERENDER_LINE) {
        if (line == PRERENDER_LINE && dot == 1) {
            p->status &= (uint8_t)~(ST_VBLANK | ST_SPR0 | ST_OVERFLOW);
            p->suppress_vbl = false;
        }

        if (line < PPU_HEIGHT && dot >= 1 && dot <= 256) {
            render_pixel(p);
        }

        if (rendering) {
            if ((dot >= 2 && dot <= 257) || (dot >= 322 && dot <= 337)) {
                shift_bg(p);
                fetch_bg_step(p);
            }
            if (dot == 256) {
                inc_fine_y(p);
            }
            if (dot == 257) {
                load_bg_shifters(p);
                transfer_x(p);
                evaluate_sprites(p, line == PRERENDER_LINE ? 0 : line + 1);
            }
            if (dot >= 257 && dot <= 320) {
                fetch_sprite_step(p);
            }
            if (line == PRERENDER_LINE && dot >= 280 && dot <= 304) {
                transfer_y(p);
            }
        }
    }

    if (line == 241 && dot == 1) {
        if (!p->suppress_vbl) {
            p->status |= ST_VBLANK;
            if (p->ctrl & CTRL_NMI) {
                p->nmi_pending = true;
            }
        }
        p->suppress_vbl = false;
        p->frame_done = true;
    }

    /* Advance the dot/scanline counter. The pre-render line of odd frames is
     * one dot shorter while rendering is enabled. */
    int last = (line == PRERENDER_LINE && p->odd_frame && rendering) ? LAST_DOT - 1 : LAST_DOT;
    if (dot >= last) {
        p->dot = 0;
        p->scanline++;
        if (p->scanline > PRERENDER_LINE) {
            p->scanline = 0;
            p->odd_frame = !p->odd_frame;
        }
    } else {
        p->dot++;
    }
}

bool ppu_take_nmi(PPU *p) {
    bool n = p->nmi_pending;
    p->nmi_pending = false;
    return n;
}

bool ppu_take_frame(PPU *p) {
    bool f = p->frame_done;
    p->frame_done = false;
    return f;
}
