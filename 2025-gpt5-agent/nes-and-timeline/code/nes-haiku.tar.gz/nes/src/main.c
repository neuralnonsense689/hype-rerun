/* Frontend: SDL2 window, keyboard input, audio pacing, battery save files. */
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "audio_out.h"
#include "cart.h"
#include "nes.h"

#define DEFAULT_SCALE 3
#define NES_W 256
#define NES_H 240
/* Keep roughly 90 ms of audio queued; the emulator runs only when below this. */
#define AUDIO_QUEUE_TARGET 4096u
/* NTSC frame period when audio is unavailable. */
#define FRAME_SECONDS (1.0 / 60.0988)

static const char *usage =
    "usage: nes [-s SCALE] ROM.nes\n"
    "  Keys: arrows = D-pad, X = A, Z = B, Right Shift = Select, Enter = Start\n"
    "        R = reset, Esc = quit\n";

/* Builds "<rom>.sav" next to the ROM, replacing its extension. */
static void make_sav_path(const char *rom, char *out, size_t outlen) {
    snprintf(out, outlen, "%s", rom);
    char *dot = strrchr(out, '.');
    char *slash = strrchr(out, '/');
    if (dot && (!slash || dot > slash)) {
        *dot = '\0';
    }
    size_t used = strlen(out);
    snprintf(out + used, outlen - used, ".sav");
}

static uint8_t read_pad(void) {
    const Uint8 *k = SDL_GetKeyboardState(NULL);
    uint8_t b = 0;
    if (k[SDL_SCANCODE_X]) b |= NES_BTN_A;
    if (k[SDL_SCANCODE_Z]) b |= NES_BTN_B;
    if (k[SDL_SCANCODE_RSHIFT] || k[SDL_SCANCODE_LSHIFT]) b |= NES_BTN_SELECT;
    if (k[SDL_SCANCODE_RETURN] || k[SDL_SCANCODE_KP_ENTER]) b |= NES_BTN_START;
    if (k[SDL_SCANCODE_UP]) b |= NES_BTN_UP;
    if (k[SDL_SCANCODE_DOWN]) b |= NES_BTN_DOWN;
    if (k[SDL_SCANCODE_LEFT]) b |= NES_BTN_LEFT;
    if (k[SDL_SCANCODE_RIGHT]) b |= NES_BTN_RIGHT;
    return b;
}

int main(int argc, char **argv) {
    int scale = DEFAULT_SCALE;
    const char *rom = NULL;
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-s") == 0 && i + 1 < argc) {
            scale = atoi(argv[++i]);
            if (scale < 1) scale = 1;
        } else if (argv[i][0] != '-') {
            rom = argv[i];
        } else {
            fputs(usage, stderr);
            return 2;
        }
    }
    if (!rom) {
        fputs(usage, stderr);
        return 2;
    }

    char err[256];
    Cart *cart = cart_load(rom, err, sizeof err);
    if (!cart) {
        fprintf(stderr, "error: %s: %s\n", rom, err);
        return 1;
    }

    char sav[1024];
    make_sav_path(rom, sav, sizeof sav);
    if (cart_has_battery(cart)) {
        if (cart_load_sram(cart, sav)) {
            fprintf(stderr, "loaded save RAM from %s\n", sav);
        }
    }

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        fprintf(stderr, "error: SDL_Init: %s\n", SDL_GetError());
        cart_free(cart);
        return 1;
    }

    AudioOut *audio = audio_open(44100);
    if (!audio) {
        fprintf(stderr, "warning: no audio device (%s); running unpaced\n", SDL_GetError());
    }
    int rate = audio ? audio_rate(audio) : 44100;

    Nes *nes = nes_new(cart, rate, audio_sink, audio);
    if (!nes) {
        fprintf(stderr, "error: out of memory\n");
        audio_close(audio);
        SDL_Quit();
        cart_free(cart);
        return 1;
    }

    char title[300];
    snprintf(title, sizeof title, "NES - %s", strrchr(rom, '/') ? strrchr(rom, '/') + 1 : rom);
    SDL_Window *win = SDL_CreateWindow(title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                       NES_W * scale, NES_H * scale,
                                       SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    SDL_Renderer *ren = win ? SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED) : NULL;
    if (!ren && win) {
        ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_SOFTWARE);
    }
    SDL_Texture *tex = ren ? SDL_CreateTexture(ren, SDL_PIXELFORMAT_ARGB8888,
                                               SDL_TEXTUREACCESS_STREAMING, NES_W, NES_H)
                           : NULL;
    if (!tex) {
        fprintf(stderr, "error: video setup failed: %s\n", SDL_GetError());
        nes_free(nes);
        audio_close(audio);
        SDL_Quit();
        cart_free(cart);
        return 1;
    }
    SDL_RenderSetLogicalSize(ren, NES_W, NES_H);

    Uint64 perf_hz = SDL_GetPerformanceFrequency();
    Uint64 next_frame = SDL_GetPerformanceCounter();
    bool running = true;

    while (running) {
        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) {
                running = false;
            } else if (ev.type == SDL_KEYDOWN && !ev.key.repeat) {
                if (ev.key.keysym.scancode == SDL_SCANCODE_ESCAPE) {
                    running = false;
                } else if (ev.key.keysym.scancode == SDL_SCANCODE_R) {
                    nes_reset(nes);
                }
            }
        }
        if (!running) {
            break;
        }

        /* Pacing: the audio device drives emulation speed when it is available. */
        if (audio) {
            if (audio_queued(audio) >= AUDIO_QUEUE_TARGET) {
                SDL_Delay(1);
                continue;
            }
        } else {
            Uint64 now = SDL_GetPerformanceCounter();
            if (now < next_frame) {
                double wait_ms = (double)(next_frame - now) * 1000.0 / (double)perf_hz;
                if (wait_ms >= 1.0) {
                    SDL_Delay((Uint32)wait_ms);
                }
                continue;
            }
            next_frame += (Uint64)(FRAME_SECONDS * (double)perf_hz);
        }

        nes_set_buttons(nes, 0, read_pad());
        nes_run_frame(nes);
        if (audio) {
            audio_commit(audio);
        }

        SDL_UpdateTexture(tex, NULL, nes_framebuffer(nes), NES_W * (int)sizeof(uint32_t));
        SDL_RenderClear(ren);
        SDL_RenderCopy(ren, tex, NULL, NULL);
        SDL_RenderPresent(ren);
    }

    if (cart_has_battery(cart)) {
        if (cart_save_sram(cart, sav)) {
            fprintf(stderr, "saved save RAM to %s\n", sav);
        } else {
            fprintf(stderr, "warning: could not write %s\n", sav);
        }
    }

    SDL_DestroyTexture(tex);
    SDL_DestroyRenderer(ren);
    SDL_DestroyWindow(win);
    nes_free(nes);
    audio_close(audio);
    SDL_Quit();
    cart_free(cart);
    return 0;
}
