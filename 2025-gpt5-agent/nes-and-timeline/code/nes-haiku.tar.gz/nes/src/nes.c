/* NES system glue. Every CPU bus access advances the rest of the machine by one
 * CPU cycle (3 PPU dots, 1 APU cycle), so the CPU sees the PPU and APU at the
 * correct points within each instruction. */
#include "nes.h"

#include <stdlib.h>
#include <string.h>

#include "cpu.h"
#include "ppu.h"

struct Nes {
    CPU cpu;
    PPU *ppu;
    APU apu;
    Cart *cart;
    uint8_t ram[0x800];

    uint8_t pad_buttons[2];  /* live state set by the frontend */
    uint8_t pad_shift[2];    /* shift register latched on strobe */
    bool strobe;
};

/* ---- system tick -------------------------------------------------------- */

static void tick(Nes *n) {
    ppu_step(n->ppu);
    ppu_step(n->ppu);
    ppu_step(n->ppu);
    apu_step(&n->apu);
    if (ppu_take_nmi(n->ppu)) {
        n->cpu.nmi = true;
    }
    n->cpu.irq = apu_irq(&n->apu) || cart_irq_pending(n->cart);
}

/* ---- memory map --------------------------------------------------------- */

static uint8_t controller_read(Nes *n, int port) {
    if (n->strobe) {
        return (n->pad_buttons[port] & NES_BTN_A) | 0x40;
    }
    uint8_t bit = n->pad_shift[port] & 1;
    n->pad_shift[port] = (uint8_t)((n->pad_shift[port] >> 1) | 0x80);
    return bit | 0x40;
}

/* Read without advancing the system. Used by the DMA engine and the bus. */
static uint8_t raw_read(Nes *n, uint16_t addr) {
    if (addr < 0x2000) {
        return n->ram[addr & 0x07FF];
    }
    if (addr < 0x4000) {
        return ppu_read_reg(n->ppu, addr);
    }
    if (addr == 0x4015) {
        return apu_read_status(&n->apu);
    }
    if (addr == 0x4016) {
        return controller_read(n, 0);
    }
    if (addr == 0x4017) {
        return controller_read(n, 1);
    }
    if (addr >= 0x4020) {
        return cart_cpu_read(n->cart, addr);
    }
    return 0; /* APU/IO not otherwise readable; open bus not modelled */
}

static void raw_write(Nes *n, uint16_t addr, uint8_t value) {
    if (addr < 0x2000) {
        n->ram[addr & 0x07FF] = value;
    } else if (addr < 0x4000) {
        ppu_write_reg(n->ppu, addr, value);
    } else if (addr == 0x4014) {
        /* OAM DMA: 513 cycles (514 on an odd cycle). Reads and writes alternate. */
        uint16_t page = (uint16_t)value << 8;
        tick(n);
        if (n->cpu.cycles & 1) {
            tick(n);
        }
        for (int i = 0; i < 256; i++) {
            uint8_t v = raw_read(n, (uint16_t)(page + i));
            tick(n);
            ppu_oam_dma_write(n->ppu, v);
            tick(n);
        }
    } else if (addr == 0x4016) {
        n->strobe = (value & 1) != 0;
        if (n->strobe) {
            n->pad_shift[0] = n->pad_buttons[0];
            n->pad_shift[1] = n->pad_buttons[1];
        }
    } else if (addr < 0x4018) {
        apu_write(&n->apu, addr, value);
    } else if (addr >= 0x4020) {
        cart_cpu_write(n->cart, addr, value);
    }
}

static uint8_t bus_read(void *ctx, uint16_t addr) {
    Nes *n = ctx;
    tick(n);
    return raw_read(n, addr);
}

static void bus_write(void *ctx, uint16_t addr, uint8_t value) {
    Nes *n = ctx;
    tick(n);
    raw_write(n, addr, value);
}

/* DMC sample fetch: reads ROM/RAM directly, without advancing the system. */
static uint8_t dmc_read(void *ctx, uint16_t addr) {
    Nes *n = ctx;
    return cart_cpu_read(n->cart, addr);
}

/* ---- public API --------------------------------------------------------- */

Nes *nes_new(Cart *cart, double audio_rate, ApuSampleSink sink, void *sink_ctx) {
    Nes *n = calloc(1, sizeof *n);
    if (!n) {
        return NULL;
    }
    n->ppu = calloc(1, sizeof *n->ppu);
    if (!n->ppu) {
        free(n);
        return NULL;
    }
    n->cart = cart;
    ppu_init(n->ppu, cart);

    CpuBus bus = {bus_read, bus_write, n};
    cpu_init(&n->cpu, bus);

    /* 1789773 Hz is the NTSC CPU clock. */
    apu_init(&n->apu, audio_rate, 1789773.0, sink, sink_ctx, dmc_read, n);

    nes_reset(n);
    return n;
}

void nes_free(Nes *n) {
    if (!n) {
        return;
    }
    free(n->ppu);
    free(n);
}

void nes_reset(Nes *n) {
    cart_reset(n->cart);
    ppu_reset(n->ppu);
    apu_reset(&n->apu);
    n->strobe = false;
    n->pad_shift[0] = n->pad_shift[1] = 0;
    cpu_reset(&n->cpu);
}

void nes_set_buttons(Nes *n, int port, uint8_t buttons) {
    if (port >= 0 && port < 2) {
        n->pad_buttons[port] = buttons;
    }
}

void nes_run_frame(Nes *n) {
    /* Frame completion is flagged by the PPU at the start of vblank. */
    while (!ppu_take_frame(n->ppu)) {
        cpu_step(&n->cpu);
    }
}

const uint32_t *nes_framebuffer(const Nes *n) {
    return n->ppu->framebuffer;
}

Cart *nes_cart(Nes *n) {
    return n->cart;
}
