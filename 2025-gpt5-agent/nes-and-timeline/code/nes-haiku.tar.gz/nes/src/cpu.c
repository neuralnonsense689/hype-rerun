/* 2A03 CPU core. Each opcode performs the same bus accesses as the real chip
 * (including dummy reads/writes), so instruction timing matches hardware. */
#include "cpu.h"

#include <stdio.h>

#define FLAG_C CPU_FLAG_C
#define FLAG_Z CPU_FLAG_Z
#define FLAG_I CPU_FLAG_I
#define FLAG_V CPU_FLAG_V
#define FLAG_N CPU_FLAG_N

#define VEC_NMI 0xFFFA
#define VEC_RESET 0xFFFC
#define VEC_IRQ 0xFFFE

typedef enum {
    M_IMP, M_ACC, M_IMM, M_ZP, M_ZPX, M_ZPY, M_ABS, M_ABX, M_ABY, M_INDX, M_INDY
} Mode;

typedef enum {
    K_ORA, K_AND, K_EOR, K_ADC, K_SBC, K_CMP,
    K_ASL, K_ROL, K_LSR, K_ROR, K_INC, K_DEC,
    /* undocumented read-modify-write combos */
    K_SLO, K_RLA, K_SRE, K_RRA, K_DCP, K_ISC
} Kind;

/* ---- bus helpers: one call == one CPU cycle ---------------------------- */

static uint8_t rd(CPU *c, uint16_t addr) {
    c->cycles++;
    return c->bus.read(c->bus.ctx, addr);
}

static void wr(CPU *c, uint16_t addr, uint8_t value) {
    c->cycles++;
    c->bus.write(c->bus.ctx, addr, value);
}

static uint8_t fetch(CPU *c) {
    return rd(c, c->pc++);
}

static void push(CPU *c, uint8_t value) {
    wr(c, 0x0100 | c->s, value);
    c->s--;
}

static uint8_t pull(CPU *c) {
    c->s++;
    return rd(c, 0x0100 | c->s);
}

/* ---- flag helpers ------------------------------------------------------- */

static void set_nz(CPU *c, uint8_t v) {
    c->p = (uint8_t)((c->p & ~(FLAG_N | FLAG_Z)) | (v & FLAG_N) | (v == 0 ? FLAG_Z : 0));
}

static void set_flag(CPU *c, uint8_t flag, bool on) {
    c->p = (uint8_t)(on ? (c->p | flag) : (c->p & ~flag));
}

/* ---- addressing ---------------------------------------------------------
 * Returns the effective address for a memory mode, performing the same bus
 * accesses as hardware. 'write' selects the store/RMW timing, which always
 * includes the dummy read on indexed page-cross paths. */
static uint16_t effective_addr(CPU *c, Mode mode, bool write) {
    switch (mode) {
    case M_ZP:
        return fetch(c);
    case M_ZPX: {
        uint8_t base = fetch(c);
        rd(c, base); /* dummy read on zero page */
        return (uint8_t)(base + c->x);
    }
    case M_ZPY: {
        uint8_t base = fetch(c);
        rd(c, base);
        return (uint8_t)(base + c->y);
    }
    case M_ABS: {
        uint16_t lo = fetch(c);
        uint16_t hi = fetch(c);
        return (uint16_t)(hi << 8 | lo);
    }
    case M_ABX:
    case M_ABY: {
        uint16_t lo = fetch(c);
        uint16_t hi = fetch(c);
        uint16_t base = (uint16_t)(hi << 8 | lo);
        uint8_t idx = (mode == M_ABX) ? c->x : c->y;
        uint16_t addr = (uint16_t)(base + idx);
        uint16_t unfixed = (base & 0xFF00) | (addr & 0x00FF);
        if (write || unfixed != addr) {
            rd(c, unfixed); /* dummy read; the fixed-up read follows */
        }
        return addr;
    }
    case M_INDX: {
        uint8_t zp = (uint8_t)(fetch(c) + c->x);
        rd(c, zp);
        uint16_t lo = rd(c, zp);
        uint16_t hi = rd(c, (uint8_t)(zp + 1));
        return (uint16_t)(hi << 8 | lo);
    }
    case M_INDY: {
        uint8_t zp = fetch(c);
        uint16_t lo = rd(c, zp);
        uint16_t hi = rd(c, (uint8_t)(zp + 1));
        uint16_t base = (uint16_t)(hi << 8 | lo);
        uint16_t addr = (uint16_t)(base + c->y);
        uint16_t unfixed = (base & 0xFF00) | (addr & 0x00FF);
        if (write || unfixed != addr) {
            rd(c, unfixed);
        }
        return addr;
    }
    default:
        return 0; /* not reached for memory modes */
    }
}

static uint8_t read_operand(CPU *c, Mode mode) {
    if (mode == M_IMM) {
        return fetch(c);
    }
    return rd(c, effective_addr(c, mode, false));
}

/* ---- ALU operations ----------------------------------------------------- */

static void op_adc(CPU *c, uint8_t v) {
    unsigned carry = c->p & FLAG_C;
    unsigned sum = c->a + v + carry;
    set_flag(c, FLAG_C, sum > 0xFF);
    set_flag(c, FLAG_V, (~(c->a ^ v) & (c->a ^ sum) & 0x80) != 0);
    c->a = (uint8_t)sum;
    set_nz(c, c->a);
}

static void op_compare(CPU *c, uint8_t reg, uint8_t v) {
    unsigned diff = (unsigned)reg - v;
    set_flag(c, FLAG_C, reg >= v);
    set_nz(c, (uint8_t)diff);
}

static void alu(CPU *c, Kind k, uint8_t v) {
    switch (k) {
    case K_ORA: c->a |= v; set_nz(c, c->a); break;
    case K_AND: c->a &= v; set_nz(c, c->a); break;
    case K_EOR: c->a ^= v; set_nz(c, c->a); break;
    case K_ADC: op_adc(c, v); break;
    case K_SBC: op_adc(c, (uint8_t)~v); break;
    case K_CMP: op_compare(c, c->a, v); break;
    default: break;
    }
}

/* Shift/rotate/inc/dec on a value; returns the new value. */
static uint8_t shift_op(CPU *c, Kind k, uint8_t v) {
    uint8_t carry_in = (c->p & FLAG_C) ? 1 : 0;
    switch (k) {
    case K_ASL:
        set_flag(c, FLAG_C, v & 0x80);
        v = (uint8_t)(v << 1);
        break;
    case K_LSR:
        set_flag(c, FLAG_C, v & 0x01);
        v = (uint8_t)(v >> 1);
        break;
    case K_ROL:
        set_flag(c, FLAG_C, v & 0x80);
        v = (uint8_t)((v << 1) | carry_in);
        break;
    case K_ROR:
        set_flag(c, FLAG_C, v & 0x01);
        v = (uint8_t)((v >> 1) | (carry_in << 7));
        break;
    case K_INC: v = (uint8_t)(v + 1); break;
    case K_DEC: v = (uint8_t)(v - 1); break;
    default: break;
    }
    set_nz(c, v);
    return v;
}

/* Read-modify-write: dummy-writes the old value before the new one, as the
 * hardware does. Undocumented combos apply a shift then an ALU op. */
static void rmw(CPU *c, Mode mode, Kind k) {
    uint8_t v;
    uint16_t addr = 0;
    if (mode == M_ACC) {
        rd(c, c->pc); /* dummy read of the byte after the opcode */
        v = c->a;
    } else {
        addr = effective_addr(c, mode, true);
        v = rd(c, addr);
        wr(c, addr, v); /* dummy write of the unmodified value */
    }

    switch (k) {
    case K_SLO: v = shift_op(c, K_ASL, v); alu(c, K_ORA, v); break;
    case K_RLA: v = shift_op(c, K_ROL, v); alu(c, K_AND, v); break;
    case K_SRE: v = shift_op(c, K_LSR, v); alu(c, K_EOR, v); break;
    case K_RRA: v = shift_op(c, K_ROR, v); alu(c, K_ADC, v); break;
    case K_DCP: v = (uint8_t)(v - 1); op_compare(c, c->a, v); break;
    case K_ISC: v = (uint8_t)(v + 1); alu(c, K_SBC, v); break;
    default: v = shift_op(c, k, v); break;
    }

    if (mode == M_ACC) {
        c->a = v;
    } else {
        wr(c, addr, v);
    }
}

/* ---- control flow ------------------------------------------------------- */

static void branch(CPU *c, bool taken) {
    int8_t off = (int8_t)fetch(c);
    if (!taken) {
        return;
    }
    rd(c, c->pc); /* dummy read on the taken path */
    uint16_t target = (uint16_t)(c->pc + off);
    if ((target & 0xFF00) != (c->pc & 0xFF00)) {
        rd(c, (c->pc & 0xFF00) | (target & 0x00FF)); /* page-cross dummy read */
    }
    c->pc = target;
}

/* Hardware interrupt sequence (NMI, IRQ). 7 cycles. */
static void interrupt(CPU *c, uint16_t vector) {
    rd(c, c->pc);
    rd(c, c->pc);
    push(c, (uint8_t)(c->pc >> 8));
    push(c, (uint8_t)c->pc);
    push(c, (uint8_t)((c->p & ~CPU_FLAG_B) | CPU_FLAG_U));
    c->p |= FLAG_I;
    uint16_t lo = rd(c, vector);
    uint16_t hi = rd(c, (uint16_t)(vector + 1));
    c->pc = (uint16_t)(hi << 8 | lo);
}

static void brk(CPU *c) {
    fetch(c); /* padding byte */
    push(c, (uint8_t)(c->pc >> 8));
    push(c, (uint8_t)c->pc);
    push(c, (uint8_t)(c->p | CPU_FLAG_B | CPU_FLAG_U));
    c->p |= FLAG_I;
    uint16_t lo = rd(c, VEC_IRQ);
    uint16_t hi = rd(c, VEC_IRQ + 1);
    c->pc = (uint16_t)(hi << 8 | lo);
}

/* ---- public API --------------------------------------------------------- */

void cpu_init(CPU *c, CpuBus bus) {
    c->bus = bus;
    c->a = c->x = c->y = 0;
    c->s = 0xFD;
    c->p = FLAG_I | CPU_FLAG_U;
    c->pc = 0;
    c->nmi = false;
    c->irq = false;
    c->jammed = false;
    c->cycles = 0;
    c->trace_unknown = true;
}

void cpu_reset(CPU *c) {
    c->s = (uint8_t)(c->s - 3);
    c->p |= FLAG_I;
    c->nmi = false;
    c->irq = false;
    c->jammed = false;
    uint16_t lo = rd(c, VEC_RESET);
    uint16_t hi = rd(c, VEC_RESET + 1);
    c->pc = (uint16_t)(hi << 8 | lo);
}

void cpu_step(CPU *c) {
    if (c->jammed) {
        rd(c, c->pc); /* keep the rest of the machine ticking */
        return;
    }
    if (c->nmi) {
        c->nmi = false;
        interrupt(c, VEC_NMI);
        return;
    }
    if (c->irq && !(c->p & FLAG_I)) {
        interrupt(c, VEC_IRQ);
        return;
    }

    uint8_t op = fetch(c);
    switch (op) {
    /* ---- ALU group: ORA, AND, EOR, ADC, CMP, SBC ---- */
    case 0x09: alu(c, K_ORA, read_operand(c, M_IMM)); break;
    case 0x05: alu(c, K_ORA, read_operand(c, M_ZP)); break;
    case 0x15: alu(c, K_ORA, read_operand(c, M_ZPX)); break;
    case 0x0D: alu(c, K_ORA, read_operand(c, M_ABS)); break;
    case 0x1D: alu(c, K_ORA, read_operand(c, M_ABX)); break;
    case 0x19: alu(c, K_ORA, read_operand(c, M_ABY)); break;
    case 0x01: alu(c, K_ORA, read_operand(c, M_INDX)); break;
    case 0x11: alu(c, K_ORA, read_operand(c, M_INDY)); break;

    case 0x29: alu(c, K_AND, read_operand(c, M_IMM)); break;
    case 0x25: alu(c, K_AND, read_operand(c, M_ZP)); break;
    case 0x35: alu(c, K_AND, read_operand(c, M_ZPX)); break;
    case 0x2D: alu(c, K_AND, read_operand(c, M_ABS)); break;
    case 0x3D: alu(c, K_AND, read_operand(c, M_ABX)); break;
    case 0x39: alu(c, K_AND, read_operand(c, M_ABY)); break;
    case 0x21: alu(c, K_AND, read_operand(c, M_INDX)); break;
    case 0x31: alu(c, K_AND, read_operand(c, M_INDY)); break;

    case 0x49: alu(c, K_EOR, read_operand(c, M_IMM)); break;
    case 0x45: alu(c, K_EOR, read_operand(c, M_ZP)); break;
    case 0x55: alu(c, K_EOR, read_operand(c, M_ZPX)); break;
    case 0x4D: alu(c, K_EOR, read_operand(c, M_ABS)); break;
    case 0x5D: alu(c, K_EOR, read_operand(c, M_ABX)); break;
    case 0x59: alu(c, K_EOR, read_operand(c, M_ABY)); break;
    case 0x41: alu(c, K_EOR, read_operand(c, M_INDX)); break;
    case 0x51: alu(c, K_EOR, read_operand(c, M_INDY)); break;

    case 0x69: alu(c, K_ADC, read_operand(c, M_IMM)); break;
    case 0x65: alu(c, K_ADC, read_operand(c, M_ZP)); break;
    case 0x75: alu(c, K_ADC, read_operand(c, M_ZPX)); break;
    case 0x6D: alu(c, K_ADC, read_operand(c, M_ABS)); break;
    case 0x7D: alu(c, K_ADC, read_operand(c, M_ABX)); break;
    case 0x79: alu(c, K_ADC, read_operand(c, M_ABY)); break;
    case 0x61: alu(c, K_ADC, read_operand(c, M_INDX)); break;
    case 0x71: alu(c, K_ADC, read_operand(c, M_INDY)); break;

    case 0xE9: case 0xEB: alu(c, K_SBC, read_operand(c, M_IMM)); break; /* EB: unofficial */
    case 0xE5: alu(c, K_SBC, read_operand(c, M_ZP)); break;
    case 0xF5: alu(c, K_SBC, read_operand(c, M_ZPX)); break;
    case 0xED: alu(c, K_SBC, read_operand(c, M_ABS)); break;
    case 0xFD: alu(c, K_SBC, read_operand(c, M_ABX)); break;
    case 0xF9: alu(c, K_SBC, read_operand(c, M_ABY)); break;
    case 0xE1: alu(c, K_SBC, read_operand(c, M_INDX)); break;
    case 0xF1: alu(c, K_SBC, read_operand(c, M_INDY)); break;

    case 0xC9: alu(c, K_CMP, read_operand(c, M_IMM)); break;
    case 0xC5: alu(c, K_CMP, read_operand(c, M_ZP)); break;
    case 0xD5: alu(c, K_CMP, read_operand(c, M_ZPX)); break;
    case 0xCD: alu(c, K_CMP, read_operand(c, M_ABS)); break;
    case 0xDD: alu(c, K_CMP, read_operand(c, M_ABX)); break;
    case 0xD9: alu(c, K_CMP, read_operand(c, M_ABY)); break;
    case 0xC1: alu(c, K_CMP, read_operand(c, M_INDX)); break;
    case 0xD1: alu(c, K_CMP, read_operand(c, M_INDY)); break;

    /* ---- CPX / CPY / BIT ---- */
    case 0xE0: op_compare(c, c->x, read_operand(c, M_IMM)); break;
    case 0xE4: op_compare(c, c->x, read_operand(c, M_ZP)); break;
    case 0xEC: op_compare(c, c->x, read_operand(c, M_ABS)); break;
    case 0xC0: op_compare(c, c->y, read_operand(c, M_IMM)); break;
    case 0xC4: op_compare(c, c->y, read_operand(c, M_ZP)); break;
    case 0xCC: op_compare(c, c->y, read_operand(c, M_ABS)); break;

    case 0x24: case 0x2C: {
        uint8_t v = read_operand(c, op == 0x24 ? M_ZP : M_ABS);
        set_flag(c, FLAG_Z, (c->a & v) == 0);
        set_flag(c, FLAG_V, v & 0x40);
        set_flag(c, FLAG_N, v & 0x80);
        break;
    }

    /* ---- Loads ---- */
    case 0xA9: c->a = read_operand(c, M_IMM); set_nz(c, c->a); break;
    case 0xA5: c->a = read_operand(c, M_ZP); set_nz(c, c->a); break;
    case 0xB5: c->a = read_operand(c, M_ZPX); set_nz(c, c->a); break;
    case 0xAD: c->a = read_operand(c, M_ABS); set_nz(c, c->a); break;
    case 0xBD: c->a = read_operand(c, M_ABX); set_nz(c, c->a); break;
    case 0xB9: c->a = read_operand(c, M_ABY); set_nz(c, c->a); break;
    case 0xA1: c->a = read_operand(c, M_INDX); set_nz(c, c->a); break;
    case 0xB1: c->a = read_operand(c, M_INDY); set_nz(c, c->a); break;

    case 0xA2: c->x = read_operand(c, M_IMM); set_nz(c, c->x); break;
    case 0xA6: c->x = read_operand(c, M_ZP); set_nz(c, c->x); break;
    case 0xB6: c->x = read_operand(c, M_ZPY); set_nz(c, c->x); break;
    case 0xAE: c->x = read_operand(c, M_ABS); set_nz(c, c->x); break;
    case 0xBE: c->x = read_operand(c, M_ABY); set_nz(c, c->x); break;

    case 0xA0: c->y = read_operand(c, M_IMM); set_nz(c, c->y); break;
    case 0xA4: c->y = read_operand(c, M_ZP); set_nz(c, c->y); break;
    case 0xB4: c->y = read_operand(c, M_ZPX); set_nz(c, c->y); break;
    case 0xAC: c->y = read_operand(c, M_ABS); set_nz(c, c->y); break;
    case 0xBC: c->y = read_operand(c, M_ABX); set_nz(c, c->y); break;

    /* ---- Stores ---- */
    case 0x85: wr(c, effective_addr(c, M_ZP, true), c->a); break;
    case 0x95: wr(c, effective_addr(c, M_ZPX, true), c->a); break;
    case 0x8D: wr(c, effective_addr(c, M_ABS, true), c->a); break;
    case 0x9D: wr(c, effective_addr(c, M_ABX, true), c->a); break;
    case 0x99: wr(c, effective_addr(c, M_ABY, true), c->a); break;
    case 0x81: wr(c, effective_addr(c, M_INDX, true), c->a); break;
    case 0x91: wr(c, effective_addr(c, M_INDY, true), c->a); break;

    case 0x86: wr(c, effective_addr(c, M_ZP, true), c->x); break;
    case 0x96: wr(c, effective_addr(c, M_ZPY, true), c->x); break;
    case 0x8E: wr(c, effective_addr(c, M_ABS, true), c->x); break;

    case 0x84: wr(c, effective_addr(c, M_ZP, true), c->y); break;
    case 0x94: wr(c, effective_addr(c, M_ZPX, true), c->y); break;
    case 0x8C: wr(c, effective_addr(c, M_ABS, true), c->y); break;

    /* ---- Shifts / inc / dec (read-modify-write) ---- */
    case 0x0A: rmw(c, M_ACC, K_ASL); break;
    case 0x06: rmw(c, M_ZP, K_ASL); break;
    case 0x16: rmw(c, M_ZPX, K_ASL); break;
    case 0x0E: rmw(c, M_ABS, K_ASL); break;
    case 0x1E: rmw(c, M_ABX, K_ASL); break;

    case 0x2A: rmw(c, M_ACC, K_ROL); break;
    case 0x26: rmw(c, M_ZP, K_ROL); break;
    case 0x36: rmw(c, M_ZPX, K_ROL); break;
    case 0x2E: rmw(c, M_ABS, K_ROL); break;
    case 0x3E: rmw(c, M_ABX, K_ROL); break;

    case 0x4A: rmw(c, M_ACC, K_LSR); break;
    case 0x46: rmw(c, M_ZP, K_LSR); break;
    case 0x56: rmw(c, M_ZPX, K_LSR); break;
    case 0x4E: rmw(c, M_ABS, K_LSR); break;
    case 0x5E: rmw(c, M_ABX, K_LSR); break;

    case 0x6A: rmw(c, M_ACC, K_ROR); break;
    case 0x66: rmw(c, M_ZP, K_ROR); break;
    case 0x76: rmw(c, M_ZPX, K_ROR); break;
    case 0x6E: rmw(c, M_ABS, K_ROR); break;
    case 0x7E: rmw(c, M_ABX, K_ROR); break;

    case 0xE6: rmw(c, M_ZP, K_INC); break;
    case 0xF6: rmw(c, M_ZPX, K_INC); break;
    case 0xEE: rmw(c, M_ABS, K_INC); break;
    case 0xFE: rmw(c, M_ABX, K_INC); break;

    case 0xC6: rmw(c, M_ZP, K_DEC); break;
    case 0xD6: rmw(c, M_ZPX, K_DEC); break;
    case 0xCE: rmw(c, M_ABS, K_DEC); break;
    case 0xDE: rmw(c, M_ABX, K_DEC); break;

    /* ---- Register transfers and inc/dec ---- */
    case 0xE8: c->x++; set_nz(c, c->x); rd(c, c->pc); break;
    case 0xC8: c->y++; set_nz(c, c->y); rd(c, c->pc); break;
    case 0xCA: c->x--; set_nz(c, c->x); rd(c, c->pc); break;
    case 0x88: c->y--; set_nz(c, c->y); rd(c, c->pc); break;
    case 0xAA: c->x = c->a; set_nz(c, c->x); rd(c, c->pc); break;
    case 0xA8: c->y = c->a; set_nz(c, c->y); rd(c, c->pc); break;
    case 0x8A: c->a = c->x; set_nz(c, c->a); rd(c, c->pc); break;
    case 0x98: c->a = c->y; set_nz(c, c->a); rd(c, c->pc); break;
    case 0x9A: c->s = c->x; rd(c, c->pc); break;
    case 0xBA: c->x = c->s; set_nz(c, c->x); rd(c, c->pc); break;

    /* ---- Stack ---- */
    case 0x48: rd(c, c->pc); push(c, c->a); break;
    case 0x08: rd(c, c->pc); push(c, c->p | CPU_FLAG_B | CPU_FLAG_U); break;
    case 0x68:
        rd(c, c->pc);
        rd(c, 0x0100 | c->s);
        c->a = pull(c);
        set_nz(c, c->a);
        break;
    case 0x28:
        rd(c, c->pc);
        rd(c, 0x0100 | c->s);
        c->p = (uint8_t)((pull(c) & ~CPU_FLAG_B) | CPU_FLAG_U);
        break;

    /* ---- Flags ---- */
    case 0x18: set_flag(c, FLAG_C, false); rd(c, c->pc); break;
    case 0x38: set_flag(c, FLAG_C, true); rd(c, c->pc); break;
    case 0x58: set_flag(c, FLAG_I, false); rd(c, c->pc); break;
    case 0x78: set_flag(c, FLAG_I, true); rd(c, c->pc); break;
    case 0xB8: set_flag(c, FLAG_V, false); rd(c, c->pc); break;
    case 0xD8: set_flag(c, CPU_FLAG_D, false); rd(c, c->pc); break;
    case 0xF8: set_flag(c, CPU_FLAG_D, true); rd(c, c->pc); break;

    /* ---- Branches ---- */
    case 0x10: branch(c, !(c->p & FLAG_N)); break; /* BPL */
    case 0x30: branch(c, (c->p & FLAG_N) != 0); break; /* BMI */
    case 0x50: branch(c, !(c->p & FLAG_V)); break; /* BVC */
    case 0x70: branch(c, (c->p & FLAG_V) != 0); break; /* BVS */
    case 0x90: branch(c, !(c->p & FLAG_C)); break; /* BCC */
    case 0xB0: branch(c, (c->p & FLAG_C) != 0); break; /* BCS */
    case 0xD0: branch(c, !(c->p & FLAG_Z)); break; /* BNE */
    case 0xF0: branch(c, (c->p & FLAG_Z) != 0); break; /* BEQ */

    /* ---- Jumps and subroutines ---- */
    case 0x4C: { /* JMP abs */
        uint16_t lo = fetch(c);
        uint16_t hi = fetch(c);
        c->pc = (uint16_t)(hi << 8 | lo);
        break;
    }
    case 0x6C: { /* JMP (ind), with the original page-wrap bug */
        uint16_t lo = fetch(c);
        uint16_t hi = fetch(c);
        uint16_t ptr = (uint16_t)(hi << 8 | lo);
        uint16_t tlo = rd(c, ptr);
        uint16_t thi = rd(c, (uint16_t)((ptr & 0xFF00) | ((ptr + 1) & 0x00FF)));
        c->pc = (uint16_t)(thi << 8 | tlo);
        break;
    }
    case 0x20: { /* JSR */
        uint16_t lo = fetch(c);
        rd(c, 0x0100 | c->s);
        push(c, (uint8_t)(c->pc >> 8));
        push(c, (uint8_t)c->pc);
        uint16_t hi = fetch(c);
        c->pc = (uint16_t)(hi << 8 | lo);
        break;
    }
    case 0x60: { /* RTS */
        rd(c, c->pc);
        rd(c, 0x0100 | c->s);
        uint16_t lo = pull(c);
        uint16_t hi = pull(c);
        c->pc = (uint16_t)(hi << 8 | lo);
        rd(c, c->pc);
        c->pc++;
        break;
    }
    case 0x40: { /* RTI */
        rd(c, c->pc);
        rd(c, 0x0100 | c->s);
        c->p = (uint8_t)((pull(c) & ~CPU_FLAG_B) | CPU_FLAG_U);
        uint16_t lo = pull(c);
        uint16_t hi = pull(c);
        c->pc = (uint16_t)(hi << 8 | lo);
        break;
    }
    case 0x00: brk(c); break;

    case 0xEA: rd(c, c->pc); break; /* NOP */

    /* ---- Undocumented: LAX / SAX ---- */
    case 0xA7: c->a = c->x = read_operand(c, M_ZP); set_nz(c, c->a); break;
    case 0xB7: c->a = c->x = read_operand(c, M_ZPY); set_nz(c, c->a); break;
    case 0xAF: c->a = c->x = read_operand(c, M_ABS); set_nz(c, c->a); break;
    case 0xBF: c->a = c->x = read_operand(c, M_ABY); set_nz(c, c->a); break;
    case 0xA3: c->a = c->x = read_operand(c, M_INDX); set_nz(c, c->a); break;
    case 0xB3: c->a = c->x = read_operand(c, M_INDY); set_nz(c, c->a); break;
    case 0xAB: c->a = c->x = read_operand(c, M_IMM); set_nz(c, c->a); break; /* LXA, approximated */

    case 0x87: wr(c, effective_addr(c, M_ZP, true), c->a & c->x); break;
    case 0x97: wr(c, effective_addr(c, M_ZPY, true), c->a & c->x); break;
    case 0x8F: wr(c, effective_addr(c, M_ABS, true), c->a & c->x); break;
    case 0x83: wr(c, effective_addr(c, M_INDX, true), c->a & c->x); break;

    /* ---- Undocumented: immediate ALU ops ---- */
    case 0x0B: case 0x2B: /* ANC */
        c->a &= read_operand(c, M_IMM);
        set_nz(c, c->a);
        set_flag(c, FLAG_C, c->a & 0x80);
        break;
    case 0x4B: /* ALR */
        c->a &= read_operand(c, M_IMM);
        c->a = shift_op(c, K_LSR, c->a);
        break;
    case 0x6B: { /* ARR */
        c->a &= read_operand(c, M_IMM);
        uint8_t carry_in = (c->p & FLAG_C) ? 0x80 : 0;
        c->a = (uint8_t)((c->a >> 1) | carry_in);
        set_nz(c, c->a);
        set_flag(c, FLAG_C, c->a & 0x40);
        set_flag(c, FLAG_V, ((c->a >> 6) ^ (c->a >> 5)) & 1);
        break;
    }
    case 0xCB: { /* AXS: X = (A & X) - imm, no borrow in */
        uint8_t v = read_operand(c, M_IMM);
        uint8_t ax = c->a & c->x;
        set_flag(c, FLAG_C, ax >= v);
        c->x = (uint8_t)(ax - v);
        set_nz(c, c->x);
        break;
    }

    /* ---- Undocumented: read-modify-write combos ---- */
    case 0x07: rmw(c, M_ZP, K_SLO); break;
    case 0x17: rmw(c, M_ZPX, K_SLO); break;
    case 0x0F: rmw(c, M_ABS, K_SLO); break;
    case 0x1F: rmw(c, M_ABX, K_SLO); break;
    case 0x1B: rmw(c, M_ABY, K_SLO); break;
    case 0x03: rmw(c, M_INDX, K_SLO); break;
    case 0x13: rmw(c, M_INDY, K_SLO); break;

    case 0x27: rmw(c, M_ZP, K_RLA); break;
    case 0x37: rmw(c, M_ZPX, K_RLA); break;
    case 0x2F: rmw(c, M_ABS, K_RLA); break;
    case 0x3F: rmw(c, M_ABX, K_RLA); break;
    case 0x3B: rmw(c, M_ABY, K_RLA); break;
    case 0x23: rmw(c, M_INDX, K_RLA); break;
    case 0x33: rmw(c, M_INDY, K_RLA); break;

    case 0x47: rmw(c, M_ZP, K_SRE); break;
    case 0x57: rmw(c, M_ZPX, K_SRE); break;
    case 0x4F: rmw(c, M_ABS, K_SRE); break;
    case 0x5F: rmw(c, M_ABX, K_SRE); break;
    case 0x5B: rmw(c, M_ABY, K_SRE); break;
    case 0x43: rmw(c, M_INDX, K_SRE); break;
    case 0x53: rmw(c, M_INDY, K_SRE); break;

    case 0x67: rmw(c, M_ZP, K_RRA); break;
    case 0x77: rmw(c, M_ZPX, K_RRA); break;
    case 0x6F: rmw(c, M_ABS, K_RRA); break;
    case 0x7F: rmw(c, M_ABX, K_RRA); break;
    case 0x7B: rmw(c, M_ABY, K_RRA); break;
    case 0x63: rmw(c, M_INDX, K_RRA); break;
    case 0x73: rmw(c, M_INDY, K_RRA); break;

    case 0xC7: rmw(c, M_ZP, K_DCP); break;
    case 0xD7: rmw(c, M_ZPX, K_DCP); break;
    case 0xCF: rmw(c, M_ABS, K_DCP); break;
    case 0xDF: rmw(c, M_ABX, K_DCP); break;
    case 0xDB: rmw(c, M_ABY, K_DCP); break;
    case 0xC3: rmw(c, M_INDX, K_DCP); break;
    case 0xD3: rmw(c, M_INDY, K_DCP); break;

    case 0xE7: rmw(c, M_ZP, K_ISC); break;
    case 0xF7: rmw(c, M_ZPX, K_ISC); break;
    case 0xEF: rmw(c, M_ABS, K_ISC); break;
    case 0xFF: rmw(c, M_ABX, K_ISC); break;
    case 0xFB: rmw(c, M_ABY, K_ISC); break;
    case 0xE3: rmw(c, M_INDX, K_ISC); break;
    case 0xF3: rmw(c, M_INDY, K_ISC); break;

    /* ---- Undocumented NOPs (with their operand reads) ---- */
    case 0x1A: case 0x3A: case 0x5A: case 0x7A: case 0xDA: case 0xFA:
        rd(c, c->pc);
        break;
    case 0x80: case 0x82: case 0x89: case 0xC2: case 0xE2:
        fetch(c);
        break;
    case 0x04: case 0x44: case 0x64:
        rd(c, effective_addr(c, M_ZP, false));
        break;
    case 0x14: case 0x34: case 0x54: case 0x74: case 0xD4: case 0xF4:
        rd(c, effective_addr(c, M_ZPX, false));
        break;
    case 0x0C:
        rd(c, effective_addr(c, M_ABS, false));
        break;
    case 0x1C: case 0x3C: case 0x5C: case 0x7C: case 0xDC: case 0xFC:
        rd(c, effective_addr(c, M_ABX, false));
        break;

    /* ---- KIL: halts the CPU until reset ---- */
    case 0x02: case 0x12: case 0x22: case 0x32: case 0x42: case 0x52:
    case 0x62: case 0x72: case 0x92: case 0xB2: case 0xD2: case 0xF2:
        c->jammed = true;
        break;

    default:
        /* Remaining undocumented opcodes (XAA, AHX, SHX, SHY, TAS, LAS) are
         * unimplemented; they are treated as one-byte NOPs. */
        if (c->trace_unknown) {
            fprintf(stderr, "cpu: unimplemented opcode $%02X at $%04X (treated as NOP)\n",
                    op, (unsigned)(c->pc - 1));
            c->trace_unknown = false;
        }
        rd(c, c->pc);
        break;
    }
}
