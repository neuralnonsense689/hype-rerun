# NES emulator

A portable NES emulator in C11. Video, audio, and input use SDL2; there are no other dependencies.

## Build

```sh
make            # builds ./nes
make test       # builds and runs the headless self-tests (no SDL needed)
```

Requires a C11 compiler and SDL2 (`pkg-config --cflags --libs sdl2` must work).
On Windows (MinGW) the Makefile links `-lSDL2main` automatically.

## Run

```sh
./nes [-s SCALE] game.nes
```

| Key            | NES button     |
|----------------|----------------|
| Arrow keys     | D-pad          |
| X              | A              |
| Z              | B              |
| Right Shift    | Select         |
| Enter          | Start          |
| R              | Reset          |
| Esc            | Quit           |

Battery-backed PRG-RAM is loaded from and saved to `game.sav` next to the ROM.

## Layout

| File | Role |
|------|------|
| `src/cpu.c`, `cpu.h` | 2A03 core. Every bus access costs one cycle, with dummy reads/writes and page-cross penalties. |
| `src/ppu.c`, `ppu.h` | 2C02. Dot-driven background pipeline (loopy v/t/x), per-scanline sprite evaluation, sprite-0 hit, overflow, four-screen/H/V/single-screen mirroring. |
| `src/apu.c`, `apu.h` | 2A03 audio: two pulses, triangle, noise, DMC, frame counter, nonlinear mixer, DC-blocking filter. |
| `src/cart.c`, `cart.h`, `cart_internal.h` | iNES 1.0 loader (NES 2.0 refused), bank-map bus accessors, `.sav` persistence. |
| `src/mappers.c` | Mappers 0 (NROM), 1 (MMC1), 2 (UxROM), 3 (CNROM), 4 (MMC3), 180. |
| `src/nes.c`, `nes.h` | System glue: memory map, OAM DMA (513/514 cycles), controllers, interrupt lines. |
| `src/audio_out.c` | SDL audio device, ring buffer drained by the SDL callback. |
| `src/main.c` | SDL window, input, audio-paced frame loop. |
| `tests/test_core.c` | CPU, cycle-count, loader, mapper, PPU and boot tests. |

## Status

Working and covered by tests:
- CPU: all official opcodes plus the common undocumented ones (LAX, SAX, DCP, ISC, SLO, RLA, SRE, RRA, ALR, ANC, ARR, AXS, NOPs, KIL). Timing checked against known per-instruction cycle counts.
- PPU: backgrounds, sprites (8x8 and 8x16), priority, sprite-0 hit, overflow, grayscale, left-edge clipping, mirroring modes.
- Mappers 0, 1, 2, 3, 4, 180. MMC3 IRQ counting is tested with synthetic A12 edges.
- Battery `.sav` files.

Not implemented (deliberately out of scope or not done yet):
- **Save states.** Not implemented.
- **PAL timing.** The emulator is NTSC only; the ROM's PAL flag is parsed but ignored.
- **NES 2.0 headers** are rejected with an error.
- **Undocumented unstable opcodes** (XAA `$8B`, AHX `$93/$9F`, SHX `$9E`, SHY `$9C`, TAS `$9B`, LAS `$BB`) are treated as one-byte NOPs, with a warning printed once.
- **Accuracy gaps:** the MMC1 consecutive-write quirk, the PPU sprite-overflow evaluation bug, DMC DMA CPU stalls, open-bus reads, and PPU emphasis bits are not modelled. Sprite evaluation runs once per scanline rather than dot by dot.
- **Large MMC1 boards** (SUROM/SXROM with PRG above 256 KiB) are not bank-switched correctly.

## Verification

No commercial ROMs or conformance ROMs were available in the development environment, so
the tests use synthetic ROMs and direct CPU/PPU/mapper calls. The next recommended step is to run
the standard conformance suites (nestest, blargg's `instr_test`/`ppu_vbl_nmi`/`sprite_hit`, and the
MMC3 IRQ tests) against this build.
