/* Adapter for Terra's emulator: mirrors its main.c setup (calloc NES, cart_load, noise_lfsr=1, scanline=261, cpu_reset)
 * and its frame loop (cpu_step + nes_tick until ppu.frame changes). Pixels are ARGB8888, as its SDL texture says. */
#include <stdlib.h>
#include "nes.h"
void *emu_new(const char *rom) {
    NES *n = calloc(1, sizeof *n);
    if (!n || !cart_load(&n->cart, rom)) return NULL;
    n->apu.noise_lfsr = 1; n->ppu.scanline = 261; cpu_reset(n);
    return n;
}
void emu_frame(void *e) { NES *n = e; uint64_t f = n->ppu.frame; while (n->ppu.frame == f) nes_tick(n, cpu_step(n)); }
uint8_t emu_peek(void *e, uint16_t a) { return bus_read(e, a); }
void emu_pixel_rgb(void *e, int x, int y, uint8_t p[3]) {
    uint32_t v = ((NES *)e)->ppu.pixels[y * WIDTH + x]; p[0] = v >> 16; p[1] = v >> 8; p[2] = v;
}
void emu_buttons(void *e, uint8_t b) { ((NES *)e)->buttons[0] = b; }
void emu_reset(void *e) { cpu_reset(e); }
