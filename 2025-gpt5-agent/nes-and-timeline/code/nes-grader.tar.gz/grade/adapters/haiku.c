/* Adapter for Haiku's emulator: its own API in src/nes.h and src/cart.h, set up as its main.c does
 * (cart_load, nes_new with an audio sink; here a sink that drops samples). Pixels are ARGB8888, as its SDL texture says. */
#include <stdio.h>
#include "nes.h"
#include "cart.h"
static void drop(void *ctx, int16_t s) { (void)ctx; (void)s; }
void *emu_new(const char *rom) {
    char err[256];
    Cart *c = cart_load(rom, err, sizeof err);
    if (!c) return NULL;
    return nes_new(c, 44100, drop, NULL);
}
void emu_frame(void *e) { nes_run_frame(e); }
uint8_t emu_peek(void *e, uint16_t a) { return cart_cpu_read(nes_cart(e), a); }
void emu_pixel_rgb(void *e, int x, int y, uint8_t p[3]) {
    uint32_t v = nes_framebuffer(e)[y * 256 + x]; p[0] = v >> 16; p[1] = v >> 8; p[2] = v;
}
void emu_buttons(void *e, uint8_t b) { nes_set_buttons(e, 0, b); }
void emu_reset(void *e) { nes_reset(e); }
