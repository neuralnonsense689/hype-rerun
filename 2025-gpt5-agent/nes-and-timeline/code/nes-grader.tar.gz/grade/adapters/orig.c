/* Adapter for the original (GPT-5-Codex, 2025-10) emulator: its own public API in include/nes.h and bus.h. */
#include <stdbool.h>
#include "nes.h"
#include "bus.h"
void *emu_new(const char *rom) {
    NESConfig cfg = { .enable_audio = true, .enable_vsync = true, .keep_aspect_ratio = true };
    struct NES *n = nes_create(&cfg);
    if (!n || !nes_load_rom(n, rom)) return NULL;
    return n;   /* main.c does no reset after nes_load_rom (the load itself power-cycles) */
}
void emu_frame(void *e) { nes_run_frame(e); }
uint8_t emu_peek(void *e, uint16_t a) { return nes_cpu_read(e, a); }
void emu_pixel_rgb(void *e, int x, int y, uint8_t p[3]) {
    const NESFrameInfo *f = nes_current_frame(e);
    uint32_t v = f->pixels[y * (f->pitch / 4) + x];
    p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8);   /* SDL RGBA8888 */
}
void emu_buttons(void *e, uint8_t b) { nes_set_controller_state(e, 0, b); }
void emu_reset(void *e) { nes_reset(e); }
