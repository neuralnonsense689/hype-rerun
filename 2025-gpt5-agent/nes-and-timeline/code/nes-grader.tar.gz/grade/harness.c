/* Headless test runner for the NES rerun (2026-11-05). My code, not the models'.
 * Links one emulator's core (no SDL front end) through a small adapter in adapters/<name>.c.
 *
 *   harness <rom> <max_frames> <out.ppm> [buttons_script] [frames.rgb]
 *
 * blargg-style tests: once $6001-$6003 holds DE B0 61, $6000 is the status (0x80 running, 0x81 "press reset",
 * otherwise the final result code, 0 = pass) and $6004 holds the result text. The harness follows that protocol,
 * pressing reset when asked, and prints one line:  RESULT <code|none> frames=<n> text=<...>
 * Every run also writes the last frame as a 256x240 PPM, for tests that only report on screen.
 * The optional frames.rgb gets every frame as raw 256x240 RGB24, for making videos (ffmpeg -f rawvideo).
 * The optional buttons script is lines of "<frame> <hex buttons>" (bit0 A, 1 B, 2 Select, 3 Start, 4 Up, 5 Down, 6 Left, 7 Right).
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* adapter interface */
void *emu_new(const char *rom_path);              /* NULL if the ROM is refused */
void emu_frame(void *e);                          /* run until the next frame is complete */
uint8_t emu_peek(void *e, uint16_t addr);         /* CPU-bus read of $6000-$7FFF (cartridge RAM) */
void emu_pixel_rgb(void *e, int x, int y, uint8_t rgb[3]);
void emu_buttons(void *e, uint8_t buttons);       /* controller 1 */
void emu_reset(void *e);                          /* soft reset (the console's reset button) */

int main(int argc, char **argv) {
    if (argc < 4) { fprintf(stderr, "usage: harness rom max_frames out.ppm [buttons]\n"); return 2; }
    int max_frames = atoi(argv[2]);
    void *e = emu_new(argv[1]);
    if (!e) { printf("RESULT refused frames=0 text=\n"); return 0; }
    int script_n = 0, script_f[4096]; unsigned script_b[4096];
    if (argc > 4) {
        FILE *s = fopen(argv[4], "r");
        while (s && script_n < 4096 && fscanf(s, "%d %x", &script_f[script_n], &script_b[script_n]) == 2) script_n++;
        if (s) fclose(s);
    }
    FILE *dump = (argc > 5) ? fopen(argv[5], "wb") : NULL;
    int result = -1, frames = 0, reset_at = -1, si = 0;
    for (frames = 0; frames < max_frames; frames++) {
        while (si < script_n && script_f[si] <= frames) emu_buttons(e, (uint8_t)script_b[si++]);
        emu_frame(e);
        if (dump) for (int y = 0; y < 240; y++) for (int x = 0; x < 256; x++) { uint8_t p[3]; emu_pixel_rgb(e, x, y, p); fwrite(p, 1, 3, dump); }
        if (reset_at >= 0 && frames >= reset_at) { emu_reset(e); reset_at = -1; continue; }
        if (emu_peek(e, 0x6001) == 0xDE && emu_peek(e, 0x6002) == 0xB0 && emu_peek(e, 0x6003) == 0x61) {
            uint8_t st = emu_peek(e, 0x6000);
            if (st == 0x81 && reset_at < 0) reset_at = frames + 10;      /* about 166 ms, as the tests ask for >100 ms */
            else if (st < 0x80) { result = st; frames++; break; }
        }
    }
    if (dump) fclose(dump);
    char text[1024] = {0};
    if (emu_peek(e, 0x6001) == 0xDE) {
        for (int i = 0; i < 1000; i++) {
            uint8_t c = emu_peek(e, (uint16_t)(0x6004 + i));
            if (!c) break;
            text[i] = (c == '\n') ? '|' : (c < 32 || c > 126) ? '?' : (char)c;
        }
    }
    FILE *f = fopen(argv[3], "wb");
    if (f) {
        fprintf(f, "P6\n256 240\n255\n");
        for (int y = 0; y < 240; y++) for (int x = 0; x < 256; x++) { uint8_t p[3]; emu_pixel_rgb(e, x, y, p); fwrite(p, 1, 3, f); }
        fclose(f);
    }
    if (result >= 0) printf("RESULT %d frames=%d text=%s\n", result, frames, text);
    else printf("RESULT none frames=%d text=%s\n", frames, text);
    return 0;
}
