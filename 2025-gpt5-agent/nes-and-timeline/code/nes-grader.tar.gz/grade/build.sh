#!/usr/bin/env bash
# usage: grade/build.sh <name> <emulator source dir> — builds grade/bin/<name> from the emulator's core .c files
# (everything except its SDL front end main.c), the adapter adapters/<name>.c and harness.c, in a container with no network.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"; name=$1; src="$(cd "$2" && pwd)"
mkdir -p "$here/bin"
docker run --rm --network none -v "$src:/src:ro" -v "$here:/grade" -w /tmp hype-rerun-agent bash -c "
  files=\$(find /src -name '*.c' ! -name main.c ! -path '*/test*' ! -name audio_out.c | sort)
  incs=\$(find /src -name '*.h' -exec dirname {} \; | sort -u | sed 's/^/-I/')
  cc -std=c11 -O2 -w \$incs \$(pkg-config --cflags sdl2) /grade/harness.c /grade/adapters/$name.c \$files \$(pkg-config --libs sdl2) -lm -o /grade/bin/$name && echo built $name"
