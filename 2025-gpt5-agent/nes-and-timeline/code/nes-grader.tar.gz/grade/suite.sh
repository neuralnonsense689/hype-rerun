#!/usr/bin/env bash
# usage: grade/suite.sh <name> — runs every ROM in tests.tsv through grade/bin/<name> in a container with no network.
# Writes grade/results/<name>.tsv (rom, kind, result line) and the last frame of each ROM to ~/hype-sw-work/nes-grade/<name>/.
# Up to 3600 frames (one emulated minute) and 300 s of wall time per ROM; 4 ROMs at a time.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"; name=$1
out=$HOME/hype-sw-work/nes-grade/$name; mkdir -p "$out" "$here/results"
docker run --rm --network none -v "$here:/grade:ro" -v "$HOME/hype-rerun-src/nes-test-roms:/roms:ro" -v "$out:/out" hype-rerun-agent bash -c "
  run_one() { rom=\$1; kind=\$2; f=/out/\$(echo \$rom | tr / _ | sed 's/\.nes\$//').ppm
    r=\$(timeout 300 /grade/bin/$name /roms/\$rom 3600 \$f 2>/dev/null); rc=\$?
    [ -z \"\$r\" ] && r=\"RESULT crash_or_timeout rc=\$rc\"
    printf '%s\t%s\t%s\n' \$rom \$kind \"\$r\"; }
  export -f run_one
  cat /grade/tests.tsv | xargs -P4 -L1 bash -c 'run_one \$0 \$1'" | sort > "$here/results/$name.tsv"
awk -F'\t' '$2=="blargg"{n++; if($3 ~ /^RESULT 0 /) p++} END{printf "self-reporting tests passed: %d of %d\n", p, n}' "$here/results/$name.tsv"
