# NES

A small NTSC NES emulator in C11 using SDL2. It loads iNES 1.0 cartridges using mappers 0, 1, 2, 3, 4 and 180. NES 2.0 images are rejected. Battery RAM is saved to `<ROM filename>.sav` on normal exit.

## Build and run

Install a C11 compiler, make, and the SDL2 development package (including `sdl2-config`), then run:

```sh
make
./nes path/to/game.nes
make test
```

On Windows, use an SDL2 development installation and a make environment that provides `sdl2-config` (for example MSYS2). The window can be resized. Escape exits. Up to two SDL game controllers are also supported using their A/B, Back, Start, and D-pad buttons.

| Button | Player 1 | Player 2 |
| --- | --- | --- |
| A / B | Z / X | G / H |
| Select / Start | Right Shift / Enter | R / T |
| Direction | Arrow keys | W / S / A / D |

## Accuracy and limitations

The CPU uses instruction cycle counts and advances the PPU three ticks and the APU one tick per CPU cycle. CPU memory accesses are performed at instruction execution time, rather than on their individual bus cycles. Consequently, raster effects, DMA/interrupt edge timing, and some mapper behavior can differ from hardware. The PPU renders pixels from the current scroll state and approximates sprite overflow and MMC3 scanline IRQ clocks; it does not emulate the PPU fetch pipeline or the hardware overflow bug. APU frame sequencing, DMC DMA, and mixing are approximations. Some unofficial CPU opcodes and mapper variants are unsupported. Compatibility with particular games and hardware test suites has not been established. PAL and save states are not implemented.
