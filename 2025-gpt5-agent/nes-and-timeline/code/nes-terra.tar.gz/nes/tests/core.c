#include "../nes.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
static void setup(NES *n){memset(n,0,sizeof *n);n->cart.prg_size=32768;n->cart.prg=calloc(1,32768);n->cart.chr_size=8192;n->cart.chr=calloc(1,8192);n->cart.chr_ram=true;n->cart.ram_size=8192;n->cart.ram=calloc(1,8192);n->cart.prg[0x7ffc]=0;n->cart.prg[0x7ffd]=0x80;cpu_reset(n);}
static void cpu_test(void){NES *n=calloc(1,sizeof *n);setup(n);uint8_t code[]={0xa9,0x7f,0x69,0x01,0x85,0x10,0xa2,0x03,0xca,0xd0,0xfd,0x00};memcpy(n->cart.prg,code,sizeof code);assert(cpu_step(n)==2&&n->cpu.a==0x7f);assert(cpu_step(n)==2&&n->cpu.a==0x80&&(n->cpu.p&0xc0)==0xc0);assert(cpu_step(n)==3&&n->ram[16]==0x80);assert(cpu_step(n)==2);for(int i=0;i<3;i++){assert(cpu_step(n)==2);assert(cpu_step(n)==(i==2?2:3));}assert(n->cpu.x==0);cart_free(&n->cart);free(n);}
static void cart_test(void){NES *n=calloc(1,sizeof *n);setup(n);Cart*c=&n->cart;c->mapper=2;memset(c->prg,1,16384);memset(c->prg+16384,2,16384);assert(cart_cpu_read(c,0x8000)==1&&cart_cpu_read(c,0xc000)==2);cart_cpu_write(c,0x8000,1);assert(cart_cpu_read(c,0x8000)==2);c->mapper=1;cart_cpu_write(c,0x8000,0x80);for(int i=0;i<5;i++)cart_cpu_write(c,0xe000,(1>>i)&1);assert(cart_cpu_read(c,0x8000)==2);cart_free(c);free(n);}
static void io_test(void){NES *n=calloc(1,sizeof *n);setup(n);n->buttons[0]=0x81;bus_write(n,0x4016,1);bus_write(n,0x4016,0);for(int i=0;i<8;i++)assert((bus_read(n,0x4016)&1)==((0x81>>i)&1));assert(bus_read(n,0x4016)&1);n->ppu.scanline=241;n->ppu.dot=1;ppu_tick(n);assert(n->ppu.status&0x80);assert(ppu_read_reg(n,2)&0x80);assert(!(n->ppu.status&0x80));cart_free(&n->cart);free(n);}
int main(void){cpu_test();cart_test();io_test();puts("core tests passed");return 0;}
