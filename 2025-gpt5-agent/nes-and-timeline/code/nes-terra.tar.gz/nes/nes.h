#ifndef NES_H
#define NES_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>

#define CPU_HZ 1789773
#define WIDTH 256
#define HEIGHT 240

typedef struct NES NES;
typedef struct {
 uint8_t *prg,*chr,*ram; size_t prg_size,chr_size,ram_size; bool chr_ram,battery,four_screen; int mapper,mirror;
 uint8_t bank,chr_bank,shift,control,chr0,chr1,prg_bank,select,regs[8]; bool irq_enable,irq_pending,irq_reload; uint8_t irq_latch,irq_counter; char *save_path;
} Cart;
typedef struct { uint16_t pc; uint8_t a,x,y,s,p; uint64_t cycles; bool nmi,irq; int stall; } CPU;
typedef struct {
 uint8_t nt[4096],pal[32],oam[256],ctrl,mask,status,oam_addr,read_buffer,open_bus;
 uint16_t v,t; uint8_t fine_x; bool w; int scanline,dot; uint64_t frame; bool nmi_line,odd;
 uint32_t pixels[WIDTH*HEIGHT];
} PPU;
typedef struct {
 uint8_t reg[0x18],length[4],seq[4],env[3],env_div[3],sweep_div[2],linear; bool env_start[3],sweep_reload[2],linear_reload;
 uint16_t timer[4],period[4],noise_lfsr; uint32_t frame_cycle; bool frame_irq,dmc_irq;
 uint16_t dmc_addr,dmc_remaining,dmc_timer; uint8_t dmc_sample,dmc_bits,dmc_output; bool dmc_silence;
 double sample_clock; float queue[16384]; unsigned qread,qwrite;
} APU;
struct NES { CPU cpu; PPU ppu; APU apu; Cart cart; uint8_t ram[2048],buttons[2],shift[2]; bool strobe; };
int cart_load(Cart *,const char *); void cart_free(Cart *); void cart_save(Cart *);
uint8_t cart_cpu_read(Cart *,uint16_t); void cart_cpu_write(Cart *,uint16_t,uint8_t); uint8_t cart_ppu_read(Cart *,uint16_t); void cart_ppu_write(Cart *,uint16_t,uint8_t); void cart_scanline(Cart *);
uint8_t bus_read(NES *,uint16_t); void bus_write(NES *,uint16_t,uint8_t); void nes_tick(NES *,int);
void cpu_reset(NES *); int cpu_step(NES *);
uint8_t ppu_read_reg(NES *,uint16_t); void ppu_write_reg(NES *,uint16_t,uint8_t); void ppu_tick(NES *);
void apu_write(NES *,uint16_t,uint8_t); uint8_t apu_status(NES *); void apu_tick(NES *);
#endif
