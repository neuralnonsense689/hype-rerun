#include "nes.h"
#include <stdlib.h>
#include <string.h>
int cart_load(Cart *c,const char *path) {
 FILE *f=fopen(path,"rb"); uint8_t h[16]; size_t n;
 if(!f){perror(path);return 0;} if(fread(h,1,16,f)!=16||memcmp(h,"NES\x1a",4)){fprintf(stderr,"Invalid iNES header\n");fclose(f);return 0;}
 if((h[7]&12)==8){fprintf(stderr,"NES 2.0 is not supported\n");fclose(f);return 0;}
 c->mapper=(h[6]>>4)|(h[7]&0xf0); if(c->mapper!=0&&c->mapper!=1&&c->mapper!=2&&c->mapper!=3&&c->mapper!=4&&c->mapper!=180){fprintf(stderr,"Unsupported mapper %d\n",c->mapper);fclose(f);return 0;}
 c->prg_size=(size_t)h[4]*16384; c->chr_size=h[5]?(size_t)h[5]*8192:8192; c->chr_ram=!h[5]; c->ram_size=(size_t)(h[8]?h[8]:1)*8192; c->battery=(h[6]&2)!=0; c->four_screen=(h[6]&8)!=0; c->mirror=h[6]&1; c->shift=0x10; c->control=0x0c;
 if(!c->prg_size){fprintf(stderr,"ROM has no PRG data\n");fclose(f);return 0;}
 c->prg=malloc(c->prg_size); c->chr=calloc(1,c->chr_size); c->ram=calloc(1,c->ram_size); n=strlen(path)+5; c->save_path=malloc(n);
 if(!c->prg||!c->chr||!c->ram||!c->save_path){fprintf(stderr,"Out of memory\n");fclose(f);cart_free(c);return 0;}
 snprintf(c->save_path,n,"%s.sav",path);
 if(h[6]&4) { if(fread(c->ram+0x1000,1,512,f)!=512){fprintf(stderr,"Truncated trainer\n");fclose(f);cart_free(c);return 0;} }
 if(fread(c->prg,1,c->prg_size,f)!=c->prg_size||(!c->chr_ram&&fread(c->chr,1,c->chr_size,f)!=c->chr_size)){fprintf(stderr,"Truncated ROM\n");fclose(f);cart_free(c);return 0;} fclose(f);
 if(c->battery&&(f=fopen(c->save_path,"rb"))){fread(c->ram,1,c->ram_size,f);fclose(f);} return 1;
}
void cart_save(Cart *c){if(c->battery&&c->save_path){FILE *f=fopen(c->save_path,"wb");if(!f){perror(c->save_path);return;} if(fwrite(c->ram,1,c->ram_size,f)!=c->ram_size) fprintf(stderr,"Save write failed\n");fclose(f);}}
void cart_free(Cart *c){free(c->prg);free(c->chr);free(c->ram);free(c->save_path);memset(c,0,sizeof *c);}
uint8_t cart_cpu_read(Cart *c,uint16_t a){size_t b=0,off=a&0x1fff, banks=c->prg_size/8192;if(a>=0x6000&&a<0x8000)return c->ram[(a-0x6000)%c->ram_size]; if(a<0x8000)return 0;
 switch(c->mapper){case 1:{int mode=(c->control>>2)&3; size_t k=(a-0x8000)/0x4000, count=c->prg_size/0x4000; if(mode<2)b=((c->prg_bank&14)+k)*2+((a>>13)&1);else if(mode==2)b=(k?c->prg_bank:0)*2+((a>>13)&1);else b=(k?count-1:c->prg_bank)*2+((a>>13)&1);break;}
 case 2:b=((a<0xc000?c->bank:c->prg_size/0x4000-1)*2)+((a>>13)&1);break;
 case 180:b=((a<0xc000?0:c->bank)*2)+((a>>13)&1);break;
 case 4:{int slot=(a-0x8000)/0x2000; size_t last=banks-1, second=banks-2; if(slot==3)b=last;else if(slot==1)b=c->regs[7];else if(slot==0)b=(c->select&0x40)?second:c->regs[6];else b=(c->select&0x40)?c->regs[6]:second;break;}
 default:b=(a-0x8000)/8192;break; } return c->prg[(b%banks)*8192+off];}
void cart_cpu_write(Cart *c,uint16_t a,uint8_t v){if(a>=0x6000&&a<0x8000){c->ram[(a-0x6000)%c->ram_size]=v;return;}if(a<0x8000)return;
 switch(c->mapper){case 1:if(v&0x80){c->shift=0x10;c->control|=0x0c;}else{bool done=c->shift&1;c->shift=(c->shift>>1)|((v&1)<<4);if(done){switch((a>>13)&3){case 0:c->control=c->shift;break;case 1:c->chr0=c->shift;break;case 2:c->chr1=c->shift;break;case 3:c->prg_bank=c->shift&15;break;}c->shift=0x10;}}break;
 case 2:case 180:c->bank=v;break;case 3:c->chr_bank=v;break;case 4:switch(a&0xe001){case 0x8000:c->select=v;break;case 0x8001:c->regs[c->select&7]=v;break;case 0xa000:if(!c->four_screen)c->mirror=!(v&1);break;case 0xc000:c->irq_latch=v;break;case 0xc001:c->irq_reload=true;break;case 0xe000:c->irq_enable=false;c->irq_pending=false;break;case 0xe001:c->irq_enable=true;break;}break;}}
static size_t chr_offset(Cart *c,uint16_t a){size_t b=0;switch(c->mapper){case 1:if(c->control&16)b=(a<0x1000?c->chr0:c->chr1)*4+(a&0xfff)/1024;else b=(c->chr0&30)*4+a/1024;break;case 3:b=c->chr_bank*8+a/1024;break;case 4:{int s=a/1024;if(c->select&0x80)s=(s+4)&7;if(s<2)b=(c->regs[0]&0xfe)+s;else if(s<4)b=(c->regs[1]&0xfe)+(s-2);else b=c->regs[s-2];break;}default:b=a/1024;}return (b%(c->chr_size/1024))*1024+(a&1023);}
uint8_t cart_ppu_read(Cart *c,uint16_t a){return c->chr[chr_offset(c,a)];}void cart_ppu_write(Cart *c,uint16_t a,uint8_t v){if(c->chr_ram)c->chr[chr_offset(c,a)]=v;}
void cart_scanline(Cart *c){if(c->mapper!=4)return;if(!c->irq_counter||c->irq_reload){c->irq_counter=c->irq_latch;c->irq_reload=false;}else c->irq_counter--;if(!c->irq_counter&&c->irq_enable)c->irq_pending=true;}
